"""Автодиспетчер: план бесконфликтен по построению и после нештатных ситуаций."""
import pytest

from app import timetable
from app.dispatcher import Planner, TrainLive, detect_conflicts, validate


@pytest.fixture(scope="module")
def specs(topo, cats, cfg):
    return timetable.generate(topo, cats, cfg, 4 * 3600, 12)


def test_nominal_timetable_is_conflict_free(topo, cats, cfg, specs):
    planner = Planner(topo, cats, cfg["dispatcher"])
    plan = planner.plan(specs, {}, now=0, strategy="timetable")
    assert validate(plan, planner, {s.id: s for s in specs}, ()) == []


@pytest.mark.parametrize("strategy", ["priority", "punctual", "fifo", "hold_freight"])
def test_every_strategy_conflict_free(topo, cats, cfg, specs, strategy):
    planner = Planner(topo, cats, cfg["dispatcher"])
    window = [s for s in specs if s.sched_dep_origin() < 8 * 3600]
    plan = planner.plan(window, {}, now=4 * 3600, strategy=strategy)
    assert validate(plan, planner, {s.id: s for s in window}, ()) == []
    assert set(plan.trains) == {s.id for s in window}


def test_closure_is_respected(topo, cats, cfg, specs):
    planner = Planner(topo, cats, cfg["dispatcher"])
    window = [s for s in specs if s.sched_dep_origin() < 8 * 3600]
    closure = ((3, 5 * 3600, 6 * 3600, "closure:test"),)
    plan = planner.plan(window, {}, now=4 * 3600, strategy="priority", closures=closure)
    for tp in plan.trains.values():
        for seg, en, ex, _ in tp.segs:
            if seg == 3:
                assert ex <= 5 * 3600 or en >= 6 * 3600, f"{tp.train_id} едет по закрытому перегону"
    assert validate(plan, planner, {s.id: s for s in window}, closure) == []


def test_delay_creates_detected_conflict_and_plan_resolves_it(topo, cats, cfg, specs):
    planner = Planner(topo, cats, cfg["dispatcher"])
    window = [s for s in specs if s.sched_dep_origin() < 7 * 3600]
    first = window[0]
    now = first.sched_dep_origin()
    lives = {first.id: TrainLive("pending", first.origin, hold_until=now + 40 * 60)}
    holds = {first.id: now + 40 * 60}
    conflicts = detect_conflicts(planner, window, lives, now, 3 * 3600, (), {}, holds)
    assert conflicts, "опоздание на 40 минут должно порождать конфликты в прогнозе"
    plan = planner.plan(window, lives, now, "priority", holds=holds)
    assert validate(plan, planner, {s.id: s for s in window}, ()) == []
    assert plan.trains[first.id].legs[0].dep >= now + 40 * 60


def test_replan_speed(topo, cats, cfg, specs):
    planner = Planner(topo, cats, cfg["dispatcher"])
    window = [s for s in specs if s.sched_dep_origin() < 8 * 3600]
    plan = planner.plan(window, {}, now=4 * 3600, strategy="priority")
    assert plan.compute_ms < 2000
