"""Приём данных: дедупликация, порядок, валидация, сглаживание."""
from app.ingest import Ingestor
from app.metrics import Metrics


def msg(seq, km, mid=None, **kw):
    m = {"type": "train", "msg_id": mid or f"m{seq}", "seq": seq, "ts": 1000.0 + seq, "train_id": "П-101",
         "category": "passenger", "direction": 1, "status": "running", "segment": "SAR-SHU", "station": None,
         "km": km, "speed_kmh": 90.0}
    m.update(kw)
    return m


def test_duplicates_dropped(topo):
    ing = Ingestor(topo, Metrics())
    assert ing.process(msg(1, 1.0), 1000) is not None
    assert ing.process(msg(1, 1.0), 1000) is None
    assert ing.m.counters["messages_duplicate"] == 1


def test_out_of_order_dropped(topo):
    ing = Ingestor(topo, Metrics())
    ing.process(msg(5, 2.0), 1000)
    assert ing.process(msg(3, 1.5), 1000) is None
    assert ing.m.counters["messages_out_of_order"] == 1


def test_invalid_rejected(topo):
    ing = Ingestor(topo, Metrics())
    assert ing.process(msg(1, -999.0), 1000) is None
    assert ing.process(msg(2, 1.0, speed_kmh=900), 1000) is None
    assert ing.process(msg(3, 1.0, segment="NOPE"), 1000) is None
    assert ing.process({"garbage": True}, 1000) is None
    assert ing.m.counters["messages_invalid"] == 4


def test_smoothing_is_monotonic(topo):
    ing = Ingestor(topo, Metrics())
    a = ing.process(msg(1, 5.00), 1000)
    b = ing.process(msg(2, 4.90), 1000)   # шум «назад»
    assert b["km"] >= a["km"]
