import sys
from pathlib import Path

import pytest
import yaml

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from app.models import load_categories  # noqa: E402
from app.topology import Topology  # noqa: E402


@pytest.fixture(scope="session")
def cfg():
    return yaml.safe_load(open(ROOT / "config" / "config.yaml", encoding="utf-8"))


@pytest.fixture(scope="session")
def topo():
    return Topology.load(ROOT / "data" / "topology.json")


@pytest.fixture(scope="session")
def cats(cfg):
    return load_categories(cfg)
