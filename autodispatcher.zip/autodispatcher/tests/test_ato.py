"""Автоведение: профиль укладывается во время хода и экономит энергию."""
import pytest

from app import ato


@pytest.mark.parametrize("cat", ["express", "passenger", "freight"])
def test_optimal_profile_meets_target_time(cats, cat):
    dyn = cats[cat].dyn
    fast = ato.fastest(13000, 0, 0, dyn, 140)
    target = fast.total_time * 1.08
    p = ato.optimal(13000, 0, 0, target, dyn, 140)
    assert abs(p.total_time - target) < 5
    assert p.energy_kwh < fast.energy_kwh
    assert p.v_cruise <= dyn.vmax_kmh * ato.KMH + 1e-6


def test_profile_kinematics_consistent(cats):
    dyn = cats["passenger"].dyn
    p = ato.optimal(14000, 0, 0, 900, dyn, 120)
    x_end, v_end = p.state_at(p.total_time + 1)
    assert x_end == pytest.approx(14000, abs=1)
    assert v_end == pytest.approx(0, abs=0.01)
    xs = [p.state_at(t)[0] for t in range(0, int(p.total_time), 10)]
    assert xs == sorted(xs), "поезд не должен двигаться назад"


def test_speed_limit_respected(cats):
    p = ato.fastest(13000, 0, 0, cats["express"].dyn, 40)
    assert p.v_cruise <= 40 * ato.KMH + 1e-6
