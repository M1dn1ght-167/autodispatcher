"""Индекс качества: границы, категории, объяснимость."""
from app import quality, timetable
from app.dispatcher import Planner


def test_index_bounds_and_factors(topo, cats, cfg):
    specs = timetable.generate(topo, cats, cfg, 4 * 3600, 6)
    planner = Planner(topo, cats, cfg["dispatcher"])
    plan = planner.plan(specs, {}, now=4 * 3600, strategy="priority")
    q = quality.compute(plan, {s.id: s for s in specs}, cats, 4 * 3600, 3 * 3600, cfg["quality"], [], [], 118000)
    assert 0 <= q["value"] <= 100
    assert len(q["factors"]) == 5
    assert abs(sum(f["contribution"] for f in q["factors"]) - q["value"]) < 0.6
    losses = [f["loss"] for f in q["factors"]]
    assert losses == sorted(losses, reverse=True)


def test_categories(cfg):
    thr = cfg["quality"]["thresholds"]
    assert quality.category_of(95, thr)[1] == "Норма"
    assert quality.category_of(70, thr)[1] == "Внимание"
    assert quality.category_of(30, thr)[1] == "Критично"
    assert quality.letter_of(91) == "A" and quality.letter_of(55) == "E"


def test_unresolved_conflicts_lower_index(topo, cats, cfg):
    specs = timetable.generate(topo, cats, cfg, 4 * 3600, 6)
    planner = Planner(topo, cats, cfg["dispatcher"])
    plan = planner.plan(specs, {}, now=4 * 3600, strategy="priority")
    smap = {s.id: s for s in specs}
    base = quality.compute(plan, smap, cats, 4 * 3600, 10800, cfg["quality"], [], [], 118000)["value"]
    worse = quality.compute(plan, smap, cats, 4 * 3600, 10800, cfg["quality"], [{}] * 3, [{}], 118000)["value"]
    assert worse < base
