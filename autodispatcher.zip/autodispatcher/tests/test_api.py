"""Сквозная проверка API: вход, план, нештатная ситуация, права администратора."""
import os
import shutil
import tempfile
from pathlib import Path

_tmp = tempfile.mkdtemp()
shutil.copy(Path(__file__).resolve().parent.parent / "config" / "config.yaml", os.path.join(_tmp, "config.yaml"))
os.environ["CONFIG_PATH"] = os.path.join(_tmp, "config.yaml")   # тест не трогает рабочий конфиг
os.environ.setdefault("DB_PATH", os.path.join(_tmp, "test.db"))
os.environ.setdefault("SECRET_KEY", "test-secret")

from fastapi.testclient import TestClient  # noqa: E402

from app.main import app  # noqa: E402


def token(c, user, pwd):
    return {"Authorization": "Bearer " + c.post("/api/auth/login", json={"username": user, "password": pwd}).json()["token"]}


def test_end_to_end():
    with TestClient(app) as c:
        assert c.get("/api/health").json()["status"] in ("ok", "degraded")
        assert c.get("/api/plan").status_code == 401
        h = token(c, "dispatcher", "dispatcher")
        plan = c.get("/api/plan", headers=h).json()
        assert plan["unresolved"] == []
        assert 0 <= plan["quality"]["value"] <= 100
        r = c.post("/api/incidents", headers=h, json={"type": "closure", "segment_id": "KOK-AKB", "minutes": 20})
        assert r.status_code == 201
        assert c.put("/api/config", headers=h, json={}).status_code == 403
        ha = token(c, "admin", "admin")
        cfg = c.get("/api/config", headers=ha).json()
        assert c.put("/api/config", headers=ha, json={"quality": {"thresholds": cfg["quality"]["thresholds"]}}).status_code == 200
        assert "openapi" in c.get("/openapi.json").json()
        assert c.get("/api/report.csv", headers=h).status_code == 200
