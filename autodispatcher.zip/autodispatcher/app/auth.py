"""Базовая аутентификация: подписанные HMAC-токены, роли dispatcher и admin."""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import time

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from . import settings

_bearer = HTTPBearer(auto_error=False)


def _sign(payload: bytes) -> str:
    return hmac.new(settings.SECRET_KEY.encode(), payload, hashlib.sha256).hexdigest()


def login(username: str, password: str) -> dict | None:
    rec = settings.USERS.get(username)
    if not rec or not hmac.compare_digest(rec[0], password):
        return None
    body = json.dumps({"u": username, "r": rec[1], "exp": int(time.time()) + settings.TOKEN_TTL_S}).encode()
    token = base64.urlsafe_b64encode(body).decode().rstrip("=") + "." + _sign(body)
    return {"token": token, "role": rec[1], "username": username}


def verify(token: str | None) -> dict | None:
    if not token or "." not in token:
        return None
    b64, sig = token.rsplit(".", 1)
    try:
        body = base64.urlsafe_b64decode(b64 + "=" * (-len(b64) % 4))
    except (ValueError, TypeError):
        return None
    if not hmac.compare_digest(_sign(body), sig):
        return None
    data = json.loads(body)
    if data.get("exp", 0) < time.time():
        return None
    return {"username": data["u"], "role": data["r"]}


def current_user(cred: HTTPAuthorizationCredentials | None = Depends(_bearer)) -> dict:
    user = verify(cred.credentials if cred else None)
    if not user:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Требуется вход в систему")
    return user


def admin_user(user: dict = Depends(current_user)) -> dict:
    if user["role"] != "admin":
        raise HTTPException(status.HTTP_403_FORBIDDEN, "Изменение настроек доступно только администратору")
    return user
