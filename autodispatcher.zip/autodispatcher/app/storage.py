"""Хранилище краткосрочной истории (SQLite): снимки состояния, события, индекс качества."""
from __future__ import annotations

import json
import sqlite3
import threading
import time
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS snapshots (ts REAL, sim_t REAL, data TEXT);
CREATE INDEX IF NOT EXISTS ix_snap_ts ON snapshots(ts);
CREATE TABLE IF NOT EXISTS events (ts REAL, sim_t REAL, kind TEXT, level TEXT, message TEXT, payload TEXT);
CREATE INDEX IF NOT EXISTS ix_ev_ts ON events(ts);
CREATE TABLE IF NOT EXISTS quality (ts REAL, sim_t REAL, value REAL, category TEXT, factors TEXT);
CREATE INDEX IF NOT EXISTS ix_q_ts ON quality(ts);
"""


class Storage:
    def __init__(self, path: Path):
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self._db = sqlite3.connect(str(path), check_same_thread=False)
        self._db.execute("PRAGMA journal_mode=WAL")
        self._db.executescript(SCHEMA)
        self._lock = threading.Lock()

    def _exec(self, sql: str, args: tuple = ()) -> None:
        with self._lock:
            self._db.execute(sql, args)
            self._db.commit()

    def _query(self, sql: str, args: tuple = ()) -> list:
        with self._lock:
            return self._db.execute(sql, args).fetchall()

    def add_snapshot(self, sim_t: float, data: dict) -> None:
        self._exec("INSERT INTO snapshots VALUES (?,?,?)", (time.time(), sim_t, json.dumps(data, ensure_ascii=False)))

    def add_event(self, sim_t: float, kind: str, level: str, message: str, payload: dict | None = None) -> None:
        self._exec("INSERT INTO events VALUES (?,?,?,?,?,?)",
                   (time.time(), sim_t, kind, level, message, json.dumps(payload or {}, ensure_ascii=False)))

    def add_quality(self, sim_t: float, value: float, category: str, factors: list) -> None:
        self._exec("INSERT INTO quality VALUES (?,?,?,?,?)",
                   (time.time(), sim_t, value, category, json.dumps(factors, ensure_ascii=False)))

    def snapshots(self, minutes: float, step: int = 1) -> list[dict]:
        rows = self._query("SELECT ts, sim_t, data FROM snapshots WHERE ts >= ? ORDER BY ts",
                           (time.time() - minutes * 60,))
        return [{"ts": r[0], "sim_t": r[1], **json.loads(r[2])} for i, r in enumerate(rows) if i % max(1, step) == 0]

    def events(self, minutes: float, limit: int = 500) -> list[dict]:
        rows = self._query("SELECT ts, sim_t, kind, level, message, payload FROM events WHERE ts >= ? ORDER BY ts DESC LIMIT ?",
                           (time.time() - minutes * 60, limit))
        return [{"ts": r[0], "sim_t": r[1], "kind": r[2], "level": r[3], "message": r[4], "payload": json.loads(r[5])} for r in rows]

    def quality(self, minutes: float) -> list[dict]:
        rows = self._query("SELECT ts, sim_t, value, category FROM quality WHERE ts >= ? ORDER BY ts",
                           (time.time() - minutes * 60,))
        return [{"ts": r[0], "sim_t": r[1], "value": r[2], "category": r[3]} for r in rows]

    def purge(self, retention_hours: float) -> None:
        cutoff = time.time() - retention_hours * 3600
        for table in ("snapshots", "events", "quality"):
            self._exec(f"DELETE FROM {table} WHERE ts < ?", (cutoff,))
