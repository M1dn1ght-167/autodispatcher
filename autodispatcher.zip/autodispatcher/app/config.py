"""Загрузка и горячая перезагрузка конфигурации (YAML) без перекомпиляции."""
from __future__ import annotations

import copy
import logging
import threading
from pathlib import Path

import yaml

log = logging.getLogger("config")

# Что разрешено менять через API (остальное — только в файле)
EDITABLE = {
    "quality": {"weights", "thresholds", "params"},
    "dispatcher": {"headway_min", "crossing_gap_s", "runtime_margin", "horizon_min", "replan_interval_s"},
    "categories": {"priority"},
}


def deep_merge(base: dict, patch: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in patch.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = v
    return out


class ConfigStore:
    def __init__(self, path: Path):
        self.path = Path(path)
        self._lock = threading.Lock()
        self._mtime = 0.0
        self.data: dict = {}
        self.version = 0
        self.reload(force=True)

    def reload(self, force: bool = False) -> bool:
        try:
            mtime = self.path.stat().st_mtime
        except FileNotFoundError:
            log.error("Файл конфигурации не найден: %s", self.path)
            return False
        if not force and mtime == self._mtime:
            return False
        with self._lock:
            with open(self.path, encoding="utf-8") as f:
                data = yaml.safe_load(f) or {}
            self.validate(data)
            self.data = data
            self._mtime = mtime
            self.version += 1
        log.info("Конфигурация загружена (версия %s)", self.version)
        return True

    @staticmethod
    def validate(data: dict) -> None:
        q = data.get("quality", {})
        w = q.get("weights", {})
        if not w or any(float(v) < 0 for v in w.values()) or sum(float(v) for v in w.values()) <= 0:
            raise ValueError("quality.weights: веса должны быть неотрицательными и не все нулевыми")
        t = q.get("thresholds", {})
        if not (0 <= float(t.get("attention", 60)) <= float(t.get("norm", 80)) <= 100):
            raise ValueError("quality.thresholds: должно быть 0 ≤ attention ≤ norm ≤ 100")
        d = data.get("dispatcher", {})
        if float(d.get("headway_min", 4)) <= 0 or float(d.get("runtime_margin", 1.05)) < 1:
            raise ValueError("dispatcher: headway_min > 0, runtime_margin ≥ 1")

    def get(self) -> dict:
        with self._lock:
            return copy.deepcopy(self.data)

    def editable_view(self) -> dict:
        d = self.get()
        return {
            "quality": d["quality"],
            "dispatcher": {k: d["dispatcher"][k] for k in EDITABLE["dispatcher"] if k in d["dispatcher"]},
            "categories": {k: {"priority": v["priority"], "name": v["name"]} for k, v in d["categories"].items()},
        }

    def update(self, patch: dict) -> dict:
        clean: dict = {}
        for section, keys in EDITABLE.items():
            if section not in patch:
                continue
            if section == "categories":
                clean["categories"] = {
                    cat: {"priority": int(v["priority"])}
                    for cat, v in patch["categories"].items()
                    if cat in self.data["categories"] and isinstance(v, dict) and "priority" in v
                }
            else:
                clean[section] = {k: v for k, v in patch[section].items() if k in keys}
        merged = deep_merge(self.get(), clean)
        self.validate(merged)
        with self._lock:
            with open(self.path, "w", encoding="utf-8") as f:
                yaml.safe_dump(merged, f, allow_unicode=True, sort_keys=False)
            self.data = merged
            self._mtime = self.path.stat().st_mtime
            self.version += 1
        log.info("Конфигурация обновлена через API (версия %s)", self.version)
        return self.editable_view()
