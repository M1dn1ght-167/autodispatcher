"""Модуль автодиспетчеризации.

Алгоритм: приоритетное планирование с резервированием ресурсов
(reservation-based scheduling) и возвратом (backtracking).

1. Ресурсы участка — перегоны (однопутные) и станционные пути (ёмкость станции).
2. Поезда планируются по очереди, порядок задаётся стратегией
   (по категориям, приоритет опаздывающим, по очереди готовности, придержать грузовые).
3. Для каждого поезда на каждом перегоне ищется самое раннее «окно»:
   * встречные поезда не могут одновременно занимать однопутный перегон (+ запас на скрещение);
   * попутные идут не ближе интервала попутного следования и не обгоняют друг друга на перегоне;
   * закрытые перегоны недоступны на время закрытия.
4. Если поезду пришлось бы ждать на станции, где нет свободного пути, —
   алгоритм откатывается на предыдущую станцию и задерживает отправление там.

Результат бесконфликтен по построению; дополнительно проверяется валидатором (validate).
Все решения — рекомендации диспетчеру, а не команды СЦБ.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field

from . import ato
from .models import Category
from .topology import Topology

NEG_INF = float("-inf")

STRATEGY_LABELS = {
    "priority": "По категориям поездов",
    "punctual": "Приоритет опаздывающим",
    "fifo": "По очереди готовности",
    "hold_freight": "Придержать грузовые",
}
STRATEGY_HINTS = {
    "priority": "Скоростные, затем пассажирские, затем грузовые",
    "punctual": "Пассажирские в первую очередь, внутри — самые опаздывающие",
    "fifo": "Кто раньше готов, тот раньше едет — минимум простоев",
    "hold_freight": "Грузовые ждут на станциях формирования до нормализации",
}


@dataclass
class TrainSpec:
    id: str
    category: str
    direction: int
    path: list
    stops: frozenset
    desired_dep: float
    sched: dict = field(default_factory=dict)   # индекс станции -> (прибытие|None, отправление|None)

    @property
    def origin(self) -> int:
        return self.path[0]

    @property
    def terminal(self) -> int:
        return self.path[-1]

    def sched_dep_origin(self) -> float:
        return self.sched.get(self.origin, (None, self.desired_dep))[1] or self.desired_dep

    def sched_arr_terminal(self) -> float | None:
        return self.sched.get(self.terminal, (None, None))[0]


@dataclass
class TrainLive:
    status: str = "pending"          # pending | dwell | running | done
    station: int | None = None
    segment: int | None = None
    arr_time: float | None = None
    enter_time: float | None = None
    exit_pred: float | None = None
    hold_until: float = 0.0


@dataclass
class Leg:
    st: int
    arr: float | None
    dep: float | None
    stop: bool
    wait: float = 0.0
    blockers: tuple = ()


@dataclass
class TrainPlan:
    train_id: str
    legs: list
    segs: list                       # (сегмент, вход, выход, фиксировано)
    delay: float = 0.0
    forced: bool = False             # возврат не помог — возможна нехватка путей

    def leg_at(self, st: int) -> Leg | None:
        for leg in self.legs:
            if leg.st == st:
                return leg
        return None


@dataclass
class Plan:
    strategy: str
    now: float
    trains: dict
    compute_ms: float = 0.0


class Reservations:
    def __init__(self, nseg: int, nst: int):
        self.seg: list[list] = [[] for _ in range(nseg)]   # (вход, выход, направление, id, вид)
        self.st: list[list] = [[] for _ in range(nst)]     # (прибытие, отправление, id)

    def window(self, seg: int, direction: int, d: float, run: float, tid: str,
               headway: float, gap: float) -> tuple[float, set]:
        blockers: set = set()
        entries = self.seg[seg]
        for _ in range(500):
            moved = False
            for en, ex, dr, other, kind in entries:
                if other == tid:
                    continue
                if kind == "closure" or dr != direction:
                    if d < ex + gap and en < d + run + gap:
                        d = ex + gap
                        blockers.add(other)
                        moved = True
                else:
                    after = d >= en + headway - 1e-6 and d + run >= ex + headway - 1e-6
                    before = d + headway <= en + 1e-6 and d + run + headway <= ex + 1e-6
                    if not (after or before):
                        d = max(en + headway, ex + headway - run)
                        blockers.add(other)
                        moved = True
            if not moved:
                break
        return d, blockers

    def st_check(self, st: int, a: float, b: float, cap: int, tid: str) -> tuple[bool, tuple]:
        ov = [(max(a, x), min(b, y), o) for x, y, o in self.st[st] if o != tid and x < b and y > a]
        if len(ov) < cap:
            return True, ()
        events = []
        for x, y, _ in ov:
            events.append((x, 1))
            events.append((y, -1))
        events.sort(key=lambda e: (e[0], e[1]))
        cur = peak = 0
        for _, delta in events:
            cur += delta
            peak = max(peak, cur)
        return peak + 1 <= cap, tuple(sorted({o for _, _, o in ov}))

    def drop_station_entries(self, tid: str) -> None:
        for lst in self.st:
            lst[:] = [e for e in lst if e[2] != tid]


class Planner:
    def __init__(self, topo: Topology, cats: dict[str, Category], dcfg: dict):
        self.topo = topo
        self.cats = cats
        self.headway = float(dcfg["headway_min"]) * 60
        self.gap = float(dcfg["crossing_gap_s"])
        self.margin = float(dcfg["runtime_margin"])
        self._rt: dict = {}

    # ---------- время хода ----------
    def seg_vlim(self, seg: int, limits: dict) -> float:
        return min(self.topo.segments[seg].vmax_kmh, limits.get(seg, 1e9))

    def run_time(self, spec: TrainSpec, seg: int, stop_start: bool, stop_end: bool, limits: dict) -> float:
        vlim = self.seg_vlim(seg, limits)
        key = (spec.category, seg, stop_start, stop_end, vlim, self.margin)
        t = self._rt.get(key)
        if t is None:
            cat = self.cats[spec.category]
            vp = min(cat.vmax_kmh, vlim) * ato.KMH
            p = ato.fastest(self.topo.segments[seg].length_m, 0.0 if stop_start else vp,
                            0.0 if stop_end else vp, cat.dyn, vlim)
            t = p.total_time * self.margin
            self._rt[key] = t
        return t

    # ---------- очерёдность ----------
    def _ready(self, spec: TrainSpec, live: TrainLive | None) -> float:
        if live and live.status == "running" and live.enter_time is not None:
            return live.enter_time
        if live and live.status == "dwell" and live.arr_time is not None:
            return live.arr_time
        return spec.sched_dep_origin()

    def _lateness(self, spec: TrainSpec, live: TrainLive | None, now: float) -> float:
        if not live:
            return max(0.0, now - spec.sched_dep_origin())
        if live.status == "dwell" and live.station in spec.sched:
            dep = spec.sched[live.station][1]
            return max(0.0, now - dep) if dep else 0.0
        if live.status == "running" and live.segment is not None:
            nxt = self.topo.seg_end(self.topo.segments[live.segment], spec.direction)
            arr = spec.sched.get(nxt, (None, None))[0]
            return max(0.0, (live.exit_pred or now) - arr) if arr else 0.0
        return max(0.0, now - spec.sched_dep_origin())

    def order(self, specs: list, lives: dict, now: float, strategy: str, promote: frozenset = frozenset()) -> list:
        base = self.cats
        prio = lambda s: base[s.category].priority + (10 if s.id in promote else 0)  # noqa: E731
        if strategy == "timetable":   # построение норматива: время готовности с бонусом за приоритет
            key = lambda s: (self._ready(s, lives.get(s.id)) - 1800 * prio(s),)  # noqa: E731
        elif strategy == "fifo":
            key = lambda s: (-(s.id in promote), self._ready(s, lives.get(s.id)))  # noqa: E731
        elif strategy == "punctual":
            key = lambda s: (-(s.id in promote), -(prio(s) >= 2), -self._lateness(s, lives.get(s.id), now),  # noqa: E731
                             self._ready(s, lives.get(s.id)))
        else:
            key = lambda s: (-prio(s), self._ready(s, lives.get(s.id)))  # noqa: E731
        return sorted(specs, key=key)

    # ---------- планирование ----------
    def plan(self, specs: list, lives: dict, now: float, strategy: str = "priority",
             closures: tuple = (), limits: dict | None = None, holds: dict | None = None,
             isolated: bool = False, promote: frozenset = frozenset()) -> Plan:
        t0 = time.perf_counter()
        limits = limits or {}
        holds = holds or {}
        nseg, nst = len(self.topo.segments), len(self.topo.stations)

        def fresh() -> Reservations:
            r = Reservations(nseg, nst)
            for seg, s, e, cid in closures:
                r.seg[seg].append((s, e, 0, cid, "closure"))
            return r

        res = fresh()
        if not isolated:
            for spec in specs:
                live = lives.get(spec.id)
                if not live:
                    continue
                if live.status == "running" and live.segment is not None:
                    res.seg[live.segment].append((live.enter_time, live.exit_pred, spec.direction, spec.id, "fixed"))
                    # поезд уже идёт к станции — заранее учитываем занятие пути на ней
                    nxt = self.topo.seg_end(self.topo.segments[live.segment], spec.direction)
                    if nxt != spec.terminal:
                        res.st[nxt].append((live.exit_pred, live.exit_pred + 120, spec.id))
                elif live.status == "dwell" and live.station is not None:
                    res.st[live.station].append((live.arr_time, max(now, live.hold_until, holds.get(spec.id, 0.0)) + 120, spec.id))

        closure_end = max((e for _, _, e, _ in closures), default=None)
        plans: dict[str, TrainPlan] = {}
        for spec in self.order(specs, lives, now, strategy, promote):
            live = lives.get(spec.id) or TrainLive()
            if live.status == "done":
                continue
            r = fresh() if isolated else res
            if isolated and live.status == "running":
                r.seg[live.segment].append((live.enter_time, live.exit_pred, spec.direction, spec.id, "fixed"))
            extra_ready = None
            if strategy == "hold_freight" and spec.category == "freight" and live.status == "pending":
                extra_ready = closure_end if closure_end else now + 20 * 60
            tp = self._plan_train(spec, live, r, now, limits, holds.get(spec.id, 0.0), extra_ready)
            if tp is not None:
                plans[spec.id] = tp
        return Plan(strategy, now, plans, (time.perf_counter() - t0) * 1000)

    def _plan_train(self, spec: TrainSpec, live: TrainLive, res: Reservations, now: float,
                    limits: dict, hold: float, extra_ready: float | None) -> TrainPlan | None:
        topo, cat = self.topo, self.cats[spec.category]
        dirn = spec.direction
        fixed = None
        if live.status == "running":
            seg = topo.segments[live.segment]
            nxt = topo.seg_end(seg, dirn)
            if nxt not in spec.path:
                return None
            start = spec.path.index(nxt)
            arr0, ready0 = live.exit_pred, None
            fixed = (live.segment, live.enter_time, live.exit_pred, True)
        elif live.status == "dwell":
            start = spec.path.index(live.station)
            arr0 = live.arr_time
            ready0 = max(now, live.hold_until, hold)
            if live.station in spec.stops:
                ready0 = max(ready0, (live.arr_time or now) + cat.dwell_s)
        else:
            start, arr0 = 0, None
            ready0 = max(spec.sched_dep_origin(), now, live.hold_until, hold)
        if extra_ready:
            ready0 = max(ready0 or 0, extra_ready)

        path = spec.path[start:]
        n = len(path)
        if n == 1:   # уже на конечной
            legs = [Leg(path[0], arr0, None, True)]
            return TrainPlan(spec.id, legs, [fixed] if fixed else [], self._delay(spec, arr0))

        arr = [None] * n
        dep = [None] * n
        stop = [False] * n
        wait = [0.0] * n
        why: list = [()] * n
        runres = [0.0] * n
        arr[0] = arr0
        min_dep: dict = {}
        ignore_cap = False
        forced = False
        iters = 0
        i = 0
        while i < n - 1:
            iters += 1
            if iters > 400 and not ignore_cap:
                ignore_cap = forced = True
            s = path[i]
            seg = topo.seg_from(s, dirn).idx
            sched_stop = s in spec.stops
            if i == 0 and ready0 is not None:
                base, stopped = ready0, True
            else:
                base = arr[i] + (cat.dwell_s if sched_stop else 0.0)
                stopped = sched_stop
            if sched_stop and spec.category != "freight":
                sd = spec.sched.get(s, (None, None))[1]
                if sd:
                    base = max(base, sd)      # пассажирские не отправляются раньше расписания
            e = max(base, min_dep.get(i, NEG_INF))
            nxt = path[i + 1]
            end_stop = nxt in spec.stops or i + 1 == n - 1
            run_r = self.run_time(spec, seg, stopped, True, limits)
            d, bl = res.window(seg, dirn, e, run_r, spec.id, self.headway, self.gap)
            if not stopped and arr[i] is not None and d > arr[i] + 1:
                # вынужденная остановка: пересчитываем прибытие с торможением
                stopped = True
                if i > 0:
                    prev_seg = topo.seg_from(path[i - 1], dirn).idx
                    arr[i] = dep[i - 1] + self.run_time(spec, prev_seg, stop[i - 1], True, limits)
                d = max(d, arr[i] + 30)
                run_r = self.run_time(spec, seg, True, True, limits)
                d, bl2 = res.window(seg, dirn, d, run_r, spec.id, self.headway, self.gap)
                bl |= bl2
            if i > 0 and not ignore_cap and s != spec.terminal:
                ok, cbl = res.st_check(s, arr[i], max(d, arr[i] + 30), topo.stations[s].tracks, spec.id)
                if not ok:
                    min_dep[i - 1] = dep[i - 1] + 60
                    why[i - 1] = tuple(sorted(set(why[i - 1]) | set(cbl)))
                    i -= 1
                    continue
            dep[i] = d
            stop[i] = stopped
            wait[i] = max(0.0, d - base)
            if wait[i] > 1:
                why[i] = tuple(sorted(set(why[i]) | bl))
            run_e = self.run_time(spec, seg, stopped, end_stop, limits)
            if end_stop and spec.category != "freight":
                # не прибывать раньше расписания: растягиваем время хода (выбег), а не ждём на станции
                sa = spec.sched.get(nxt, (None, None))[0]
                if sa is not None and d + run_e < sa:
                    stretch = min(sa - d, run_e * 1.35)
                    d2, _ = res.window(seg, dirn, d, max(run_r, stretch), spec.id, self.headway, self.gap)
                    if d2 <= d + 1:
                        run_e, run_r = stretch, max(run_r, stretch)
            runres[i] = run_r
            arr[i + 1] = d + run_e
            i += 1
        stop[n - 1] = True

        segs = [fixed] if fixed else []
        for k in range(n - 1):
            segs.append((topo.seg_from(path[k], dirn).idx, dep[k], dep[k] + runres[k], False))
        legs = [Leg(path[k], arr[k], dep[k], stop[k], wait[k], why[k] if wait[k] > 1 else ()) for k in range(n)]

        # фиксируем резервы
        res.drop_station_entries(spec.id)
        for seg, en, ex, is_fixed in segs:
            if not is_fixed:
                res.seg[seg].append((en, ex, dirn, spec.id, "plan"))
        for lg in legs:
            a = lg.arr if lg.arr is not None else (lg.dep - 600 if lg.dep is not None else now)
            b = lg.dep if lg.dep is not None else a + 300
            if lg.stop or lg.dep is None or lg.arr is None:
                res.st[lg.st].append((a, b, spec.id))
            else:
                res.st[lg.st].append((a, a + 30, spec.id))
        return TrainPlan(spec.id, legs, segs, self._delay(spec, arr[n - 1]), forced)

    @staticmethod
    def _delay(spec: TrainSpec, arr_terminal: float | None) -> float:
        sched = spec.sched_arr_terminal()
        if sched is None or arr_terminal is None:
            return 0.0
        return max(0.0, arr_terminal - sched)


def plan_with_repair(planner: Planner, specs: list, lives: dict, now: float, strategy: str,
                     closures: tuple, limits: dict, holds: dict, spec_map: dict, rounds: int = 3) -> tuple:
    """Планирование с «ремонтом»: если поезд уже физически занимает путь станции
    (стоит на ней или подходит к ней) и из-за этого возникла нехватка путей,
    он получает приоритет и план пересчитывается."""
    promote: set = set()
    plan = planner.plan(specs, lives, now, strategy, closures, limits, holds)
    issues = validate(plan, planner, spec_map, closures)
    for _ in range(rounds):
        add = set()
        for i in issues:
            if i["type"] != "station":
                continue
            for tid in i["trains"]:
                lv = lives.get(tid)
                if not lv:
                    continue
                at_station = lv.status == "dwell" and lv.station == i["station"]
                approaching = lv.status == "running" and lv.segment is not None and \
                    planner.topo.seg_end(planner.topo.segments[lv.segment], spec_map[tid].direction) == i["station"]
                if at_station or approaching:
                    add.add(tid)
        if not add - promote:
            break
        promote |= add
        plan = planner.plan(specs, lives, now, strategy, closures, limits, holds, promote=frozenset(promote))
        issues = validate(plan, planner, spec_map, closures)
    return plan, issues


# ---------- проверка и конфликты ----------

def _pair_conflicts(windows: list, headway: float, gap: float) -> list:
    """windows: (сегмент, вход, выход, направление, id, фиксировано). Возвращает пары-нарушения."""
    out = []
    by_seg: dict = {}
    for w in windows:
        by_seg.setdefault(w[0], []).append(w)
    for seg, lst in by_seg.items():
        lst.sort(key=lambda w: w[1])
        for i in range(len(lst)):
            for j in range(i + 1, len(lst)):
                a, b = lst[i], lst[j]
                if b[1] > a[2] + max(headway, gap) + 1:
                    break
                if a[4] == b[4]:
                    continue
                if a[3] != b[3]:
                    if a[1] < b[2] + gap - 1 and b[1] < a[2] + gap - 1:
                        out.append(("crossing", seg, a, b))
                else:
                    if (b[1] - a[1] < headway - 1) or (b[2] - a[2] < headway - 1):
                        kind = "overtake" if b[2] < a[2] else "headway"
                        out.append((kind, seg, a, b))
    return out


def _windows(plan: Plan, specs: dict) -> list:
    out = []
    for tid, tp in plan.trains.items():
        d = specs[tid].direction
        for seg, en, ex, fixed in tp.segs:
            out.append((seg, en, ex, d, tid, fixed))
    return out


def _station_overloads(plan: Plan, topo: Topology, specs: dict) -> list:
    out = []
    per: dict = {}
    for tid, tp in plan.trains.items():
        spec = specs[tid]
        for lg in tp.legs:
            if lg.st in (spec.origin, spec.terminal) or lg.arr is None or lg.dep is None:
                continue
            per.setdefault(lg.st, []).append((lg.arr, max(lg.dep, lg.arr + 30), tid))
    for st, lst in per.items():
        cap = topo.stations[st].tracks
        events = sorted([(a, 1, t) for a, _, t in lst] + [(b, -1, t) for _, b, t in lst], key=lambda e: (e[0], e[1]))
        cur, inside = 0, set()
        for tm, delta, t in events:
            if delta > 0:
                cur += 1
                inside.add(t)
                if cur > cap:
                    out.append(("station", st, tm, tuple(sorted(inside))))
            else:
                cur -= 1
                inside.discard(t)
    return out


def validate(plan: Plan, planner: Planner, specs: dict, closures: tuple) -> list:
    """Проверка бесконфликтности плана. Пустой список — план корректен."""
    issues = []
    wins = [w for w in _windows(plan, specs)]
    for kind, seg, a, b in _pair_conflicts(wins, planner.headway, planner.gap):
        if a[5] and b[5]:
            continue        # оба уже на перегоне — фактическая ситуация, а не ошибка плана
        issues.append({"type": kind, "segment": seg, "trains": [a[4], b[4]], "at": min(a[1], b[1])})
    for seg, s, e, cid in closures:
        for w in wins:
            if w[0] == seg and not w[5] and w[1] < e and s < w[2]:
                issues.append({"type": "closure", "segment": seg, "trains": [w[4]], "at": w[1]})
    for _, st, tm, trains in _station_overloads(plan, planner.topo, specs):
        issues.append({"type": "station", "station": st, "trains": list(trains), "at": tm})
    return issues


CONFLICT_TITLES = {
    "crossing": "Скрещение на однопутном перегоне",
    "overtake": "Обгон на перегоне",
    "headway": "Занятость блок-участка (нарушение интервала)",
    "station": "Нехватка приёмо-отправочных путей",
    "closure": "Движение по закрытому перегону",
}


def projection(planner: Planner, specs_list: list, lives: dict, now: float, holds: dict) -> Plan:
    """Прогноз «без вмешательства диспетчера»: каждый поезд идёт по нормативному графику,
    сдвинутому на своё текущее отклонение (опоздание не нагоняется и не исправляется)."""
    topo = planner.topo
    trains = {}
    for spec in specs_list:
        live = lives.get(spec.id) or TrainLive()
        if live.status == "done":
            continue
        hold = max(holds.get(spec.id, 0.0), live.hold_until)
        segs, legs = [], []
        if live.status == "running":
            seg = topo.segments[live.segment]
            nxt = topo.seg_end(seg, spec.direction)
            if nxt not in spec.path:
                continue
            start = spec.path.index(nxt)
            sched_arr = spec.sched.get(nxt, (None, None))[0]
            delta = (live.exit_pred - sched_arr) if sched_arr is not None else 0.0
            segs.append((live.segment, live.enter_time, live.exit_pred, True))
        else:
            st = live.station if live.status == "dwell" and live.station is not None else spec.origin
            start = spec.path.index(st)
            sched_dep = spec.sched.get(st, (None, None))[1]
            delta = max(0.0, max(now, hold) - sched_dep) if sched_dep is not None else 0.0
        path = spec.path[start:]
        for k, st in enumerate(path):
            a, d = spec.sched.get(st, (None, None))
            legs.append(Leg(st, None if a is None else a + delta, None if d is None else d + delta, True))
            if k + 1 < len(path) and d is not None:
                a2 = spec.sched.get(path[k + 1], (None, None))[0]
                if a2 is not None:
                    segs.append((topo.seg_from(st, spec.direction).idx, d + delta, a2 + delta, False))
        if live.status == "running" and legs:
            legs[0].arr = live.exit_pred
        trains[spec.id] = TrainPlan(spec.id, legs, segs, 0.0)
    return Plan("projection", now, trains)


def detect_conflicts(planner: Planner, specs_list: list, lives: dict, now: float, horizon_s: float,
                     closures: tuple, limits: dict, holds: dict) -> list:
    """Автоматическое обнаружение конфликтов в прогнозе движения «как есть»."""
    specs = {s.id: s for s in specs_list}
    naive = projection(planner, specs_list, lives, now, holds)
    topo = planner.topo
    out, seen = [], set()
    wins = _windows(naive, specs)
    for kind, seg, a, b in _pair_conflicts(wins, planner.headway, planner.gap):
        at = max(a[1], b[1])
        if a[5] and b[5]:
            continue
        if not (now - 60 <= at <= now + horizon_s):
            continue
        key = (kind, seg, a[4], b[4])
        if key in seen:
            continue
        seen.add(key)
        sg = topo.segments[seg]
        out.append({
            "type": kind, "title": CONFLICT_TITLES[kind], "trains": [a[4], b[4]], "at": at,
            "segment": seg, "where": f"перегон {topo.stations[sg.a].name} — {topo.stations[sg.b].name}",
            "km": (topo.stations[sg.a].km + topo.stations[sg.b].km) / 2,
        })
    for seg, s, e, cid in closures:
        for w in wins:
            if w[0] == seg and not w[5] and w[1] < e and s < w[2] and now - 60 <= w[1] <= now + horizon_s:
                sg = topo.segments[seg]
                out.append({"type": "closure", "title": CONFLICT_TITLES["closure"], "trains": [w[4]], "at": max(w[1], s),
                            "segment": seg, "where": f"перегон {topo.stations[sg.a].name} — {topo.stations[sg.b].name}",
                            "km": (topo.stations[sg.a].km + topo.stations[sg.b].km) / 2})
    for _, st, tm, trains in _station_overloads(naive, topo, specs):
        if not (now - 60 <= tm <= now + horizon_s):
            continue
        key = ("station", st, trains)
        if key in seen:
            continue
        seen.add(key)
        out.append({"type": "station", "title": CONFLICT_TITLES["station"], "trains": list(trains), "at": tm,
                    "station": st, "where": f"ст. {topo.stations[st].name}", "km": topo.stations[st].km})
    out.sort(key=lambda c: c["at"])
    return out


def reason_text(tid: str, blockers: tuple, specs: dict) -> str:
    me = specs.get(tid)
    parts = []
    for b in blockers:
        if str(b).startswith("closure"):
            parts.append("закрытие перегона")
            continue
        other = specs.get(b)
        if not other or not me:
            continue
        parts.append(f"скрещение с {b}" if other.direction != me.direction else f"пропуск попутного {b}")
    return ", ".join(dict.fromkeys(parts)) or "занятость путей"


def recommendations(plan: Plan, specs: dict, topo: Topology, now: float, horizon_s: float) -> list:
    out = []
    for tid, tp in plan.trains.items():
        for lg in tp.legs:
            if lg.wait >= 60 and lg.dep is not None and now - 30 <= lg.dep <= now + horizon_s:
                out.append({
                    "train": tid, "station": topo.stations[lg.st].name, "station_idx": lg.st,
                    "until": lg.dep, "minutes": round(lg.wait / 60, 1),
                    "reason": reason_text(tid, lg.blockers, specs),
                    "text": f"Задержать {tid} на ст. {topo.stations[lg.st].name}",
                })
    out.sort(key=lambda r: r["until"])
    return out


def resolve_text(conflict: dict, plan: Plan, topo: Topology) -> str:
    a, b = conflict["trains"][0], conflict["trains"][-1]
    if conflict["type"] == "closure":
        tp = plan.trains.get(a)
        for lg in (tp.legs if tp else []):
            if lg.wait >= 30 and any(str(x).startswith("closure") for x in lg.blockers):
                return f"{a} ожидает открытия на ст. {topo.stations[lg.st].name} до {int(lg.dep) % 86400 // 3600:02d}:{int(lg.dep) % 3600 // 60:02d}"
        return "Поезд проследует до начала закрытия"
    for tid, other in ((a, b), (b, a)):
        tp = plan.trains.get(tid)
        if not tp:
            continue
        for lg in tp.legs:
            if lg.wait >= 30 and other in lg.blockers:
                return f"{tid} ожидает на ст. {topo.stations[lg.st].name} {round(lg.wait / 60)} мин"
    return "Разрешено распределением времени хода"
