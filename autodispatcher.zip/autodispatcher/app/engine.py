"""Оркестратор: связывает симулятор, приём данных, автодиспетчер, автоведение,
индекс качества, хранилище и онлайн-рассылку (WebSocket)."""
from __future__ import annotations

import asyncio
import json
import logging
import os
import random
import time
import uuid
from collections import defaultdict, deque

from fastapi import WebSocket

from . import ato, quality, timetable
from .bus import EventBus
from .config import ConfigStore
from .dispatcher import (STRATEGY_HINTS, STRATEGY_LABELS, Planner, TrainLive, detect_conflicts,
                         plan_with_repair, recommendations, resolve_text)
from .ingest import Ingestor
from .metrics import Metrics
from .models import load_categories
from .simulator import World
from .state import StateStore
from .storage import Storage
from .topology import Topology

log = logging.getLogger("engine")

INCIDENT_LABELS = {"delay": "Опоздание поезда", "signal_fault": "Неисправность сигнала", "closure": "Закрытие перегона"}
SIGNAL_FAULT_KMH = 40


def hhmm(t: float) -> str:
    t = int(t) % 86400
    return f"{t // 3600:02d}:{t % 3600 // 60:02d}"


def r1(v):
    return None if v is None else round(v, 1)


class Engine:
    def __init__(self, cfg_store: ConfigStore, topo: Topology, storage: Storage):
        self.cfg_store = cfg_store
        self.cfg = cfg_store.get()
        self.cfg_version = cfg_store.version
        self.topo = topo
        self.storage = storage
        self.metrics = Metrics()
        self.bus = EventBus()
        self.ingestor = Ingestor(topo, self.metrics)
        self.state = StateStore(topo)
        self.cats = load_categories(self.cfg)
        sim = self.cfg["simulation"]
        self.accel = float(os.getenv("SIM_ACCEL", sim["accel"]))
        h, m = (int(x) for x in str(sim["start_time"]).split(":"))
        self.t_start = h * 3600 + m * 60
        self.warm_s = float(sim["warmup_hours"]) * 3600
        self.specs = timetable.generate(topo, self.cats, self.cfg, self.t_start - self.warm_s - 1800,
                                        float(sim["timetable_hours"]))
        self.spec_by_id = {s.id: s for s in self.specs}
        self.world = World(topo, self.cats, self.specs, self.cfg)
        self.internal_sim = os.getenv("SIMULATOR", "internal") != "off"
        self.planner = Planner(topo, self.cats, self.cfg["dispatcher"])
        self.plan = None
        self.result: dict = {}
        self.mode = "auto"
        self.incidents: dict[str, dict] = {}
        self.clients: set[WebSocket] = set()
        self.traces: dict[str, list] = defaultdict(list)
        self.last_feed_real = time.monotonic()
        self._real0 = time.monotonic()
        self._sim0 = self.t_start
        self._replan_evt: asyncio.Event | None = None
        self._trigger_t: float | None = None
        self._reasons: set = set()
        self._last_strategy = None
        self._last_tick: dict = {}
        self._tasks: list = []
        self.index_history: deque = deque(maxlen=720)

    # ---------- время ----------
    def sim_now(self) -> float:
        return self._sim0 + (time.monotonic() - self._real0) * self.accel

    # ---------- запуск ----------
    def warmup(self) -> None:
        """Заполняем участок поездами: моделируем warmup_hours до старта ускоренно."""
        t = self.t_start - self.warm_s
        last_plan = float("-inf")
        while t < self.t_start:
            if t - last_plan >= 300:
                self.plan, self.result = self._compute(self._snapshot(t, "warmup"))
                last_plan = t
            self.world.step(t, self.plan.trains if self.plan else {})
            for msg in self.world.telemetry(t):
                n = self.ingestor.process(msg, t)
                if n:
                    self.state.apply(n)
            self._record_traces(t)
            t += 5
        self._real0, self._sim0 = time.monotonic(), self.t_start
        self.plan, self.result = self._compute(self._snapshot(self.t_start, "start"))
        log.info("Прогрев завершён: на участке %d поездов", sum(1 for r in self.state.trains.values() if r["status"] != "done"))

    async def start(self) -> None:
        self._replan_evt = asyncio.Event()
        await asyncio.to_thread(self.warmup)
        self.storage.add_event(self.sim_now(), "system", "info", "Система запущена, симулятор участка активен")
        self._tasks = [asyncio.create_task(c()) for c in (self._sim_loop, self._ingest_loop, self._tick_loop, self._replan_loop)]

    async def stop(self) -> None:
        for t in self._tasks:
            t.cancel()

    # ---------- циклы ----------
    async def _sim_loop(self) -> None:
        while True:
            await asyncio.sleep(0.1)
            if not self.internal_sim:
                continue
            now = self.sim_now()
            try:
                self.world.step(now, self.plan.trains if self.plan else {})
                for msg in self.world.telemetry(now):
                    self.bus.publish("telemetry.raw", msg)
            except Exception:  # noqa: BLE001
                log.exception("Ошибка симулятора")

    async def _ingest_loop(self) -> None:
        q = self.bus.subscribe("telemetry.raw")
        while True:
            batch = [await q.get()]
            while not q.empty() and len(batch) < 2000:
                batch.append(q.get_nowait())
            now = self.sim_now()
            changed = False
            for raw in batch:
                n = self.ingestor.process(raw, now)
                if n:
                    changed |= self.state.apply(n)
            self.last_feed_real = time.monotonic()
            self.metrics.set("ingest_queue_depth", q.qsize())
            if changed:
                self.request_replan("status")

    async def _tick_loop(self) -> None:
        hz = float(self.cfg.get("ui", {}).get("tick_hz", 2))
        n = 0
        while True:
            await asyncio.sleep(1 / hz)
            n += 1
            now = self.sim_now()
            try:
                self._expire_incidents(now)
                tick = self.tick_payload(now)
                self._last_tick = tick
                await self.broadcast(tick)
                self._record_traces(now)
                if n % max(1, int(hz * float(self.cfg["storage"]["snapshot_every_s"]))) == 0:
                    snap = {k: tick[k] for k in ("trains", "signals", "index", "incidents")}
                    await asyncio.to_thread(self.storage.add_snapshot, now, snap)
                if n % int(hz * 5) == 0:
                    q = self.result.get("quality")
                    if q:
                        self.index_history.append([now, q["value"]])
                        await asyncio.to_thread(self.storage.add_quality, now, q["value"], q["category"], q["factors"])
                    if self.cfg_store.reload():
                        self._apply_config()
                    self.state.prune(now)
                if n % int(hz * 3600) == 0:
                    await asyncio.to_thread(self.storage.purge, float(self.cfg["storage"]["retention_hours"]))
            except Exception:  # noqa: BLE001
                log.exception("Ошибка цикла обновления")

    async def _replan_loop(self) -> None:
        loop = asyncio.get_running_loop()
        while True:
            interval = float(self.cfg["dispatcher"]["replan_interval_s"])
            try:
                await asyncio.wait_for(self._replan_evt.wait(), timeout=interval)
                await asyncio.sleep(float(self.cfg["dispatcher"]["debounce_ms"]) / 1000)   # объединяем всплеск
            except asyncio.TimeoutError:
                self._reasons.add("periodic")
            self._replan_evt.clear()
            trigger = self._trigger_t or time.monotonic()
            reasons = sorted(self._reasons) or ["periodic"]
            self._trigger_t, self._reasons = None, set()
            try:
                snap = self._snapshot(self.sim_now(), ",".join(reasons))
                plan, result = await loop.run_in_executor(None, self._compute, snap)
                self.plan, self.result = plan, result
                self.metrics.inc("replans")
                self.metrics.replan_ms.append(result["compute_ms"])
                latency = (time.monotonic() - trigger) * 1000
                result["latency_ms"] = round(latency, 1)
                self.metrics.latency_ms.append(latency)
                await self.broadcast(result)
                if result["strategy"] != self._last_strategy or "incident" in reasons:
                    self._last_strategy = result["strategy"]
                    self.storage.add_event(snap["now"], "replan", "info",
                                           f"Перепланирование ({', '.join(reasons)}): «{result['strategy_label']}», "
                                           f"индекс {result['quality']['value']}, расчёт {result['compute_ms']:.0f} мс",
                                           {"strategy": result["strategy"], "compute_ms": result["compute_ms"]})
            except Exception:  # noqa: BLE001
                log.exception("Ошибка перепланирования")

    def request_replan(self, reason: str) -> None:
        if self._trigger_t is None:
            self._trigger_t = time.monotonic()
        self._reasons.add(reason)
        if self._replan_evt:
            self._replan_evt.set()

    def _apply_config(self) -> None:
        self.cfg = self.cfg_store.get()
        self.cats = load_categories(self.cfg)
        self.planner = Planner(self.topo, self.cats, self.cfg["dispatcher"])
        self.world.cats = self.cats
        self.world.headway = float(self.cfg["dispatcher"]["headway_min"]) * 60
        self.storage.add_event(self.sim_now(), "config", "info", "Конфигурация применена")
        self.request_replan("config")

    # ---------- планирование ----------
    def _lives(self, now: float) -> dict:
        margin = float(self.cfg["dispatcher"]["runtime_margin"])
        holds = self._holds(now)
        lives = {}
        for tid, r in self.state.trains.items():
            spec = self.spec_by_id.get(tid)
            if not spec:
                continue
            hold = holds.get(tid, 0.0)
            if r["status"] == "running" and r["segment"] is not None:
                seg = self.topo.segments[r["segment"]]
                cat = self.cats[spec.category]
                start_km = self.topo.stations[self.topo.seg_start(seg, spec.direction)].km
                x = abs(r["km"] - start_km) * 1000
                rem = max(1.0, seg.length_m - x)
                vlim = min(seg.vmax_kmh, self.world.vlim(seg.idx))
                v = min(r["speed_kmh"], min(cat.vmax_kmh, vlim)) * ato.KMH
                t_rem = ato.fastest(rem, v, 0.0, cat.dyn, vlim).total_time * margin
                exit_pred = max(now, r["ts"]) + t_rem + max(0.0, hold - now)
                lives[tid] = TrainLive("running", None, seg.idx, None, r.get("enter_time", r["ts"]), exit_pred, hold)
            elif r["status"] in ("dwell", "pending"):
                lives[tid] = TrainLive(r["status"], r["station"], None, r.get("arr_time", r["ts"]), None, None, hold)
            else:
                lives[tid] = TrainLive("done")
        return lives

    def _active_specs(self, now: float, horizon: float) -> list:
        ids = {t for t, r in self.state.trains.items() if r["status"] != "done" and t in self.spec_by_id}
        done = {t for t, r in self.state.trains.items() if r["status"] == "done"}
        for s in self.specs:
            dep = s.sched_dep_origin()
            if dep > now + horizon:
                break
            if dep >= now - 900 and s.id not in done:
                ids.add(s.id)
        return [self.spec_by_id[i] for i in ids]

    def _holds(self, now: float) -> dict:
        out: dict = {}
        for inc in self.incidents.values():
            if inc["active"] and inc["type"] == "delay":
                out[inc["train_id"]] = max(out.get(inc["train_id"], 0.0), inc["end"])
        return out

    def _constraints(self, now: float) -> tuple:
        closures, limits = [], {}
        for iid, inc in self.incidents.items():
            if not inc["active"]:
                continue
            if inc["type"] == "closure":
                closures.append((inc["segment_idx"], inc["start"], inc["end"], f"closure:{iid}"))
            elif inc["type"] == "signal_fault":
                limits[inc["segment_idx"]] = SIGNAL_FAULT_KMH
        return tuple(closures), limits

    def _snapshot(self, now: float, reason: str) -> dict:
        horizon = float(self.cfg["dispatcher"]["horizon_min"]) * 60
        closures, limits = self._constraints(now)
        return {"now": now, "reason": reason, "lives": self._lives(now), "specs": self._active_specs(now, horizon),
                "closures": closures, "limits": limits, "holds": self._holds(now), "cfg": self.cfg,
                "mode": self.mode, "planner": self.planner, "cats": self.cats,
                "incidents": [dict(i) for i in self.incidents.values() if i["active"]]}

    def _compute(self, snap: dict) -> tuple:
        t0 = time.perf_counter()
        now, cfg, planner, cats = snap["now"], snap["cfg"], snap["planner"], snap["cats"]
        horizon = float(cfg["dispatcher"]["horizon_min"]) * 60
        specs, lives = snap["specs"], snap["lives"]
        detected = detect_conflicts(planner, specs, lives, now, horizon, snap["closures"], snap["limits"], snap["holds"])
        variants = []
        for strat in cfg["dispatcher"]["strategies"]:
            p, issues = plan_with_repair(planner, specs, lives, now, strat, snap["closures"], snap["limits"],
                                         snap["holds"], self.spec_by_id)
            q = quality.compute(p, self.spec_by_id, cats, now, horizon, cfg["quality"], detected, issues,
                                self.topo.length_km * 1000)
            variants.append((strat, p, issues, q))
        if snap["mode"] != "auto" and any(v[0] == snap["mode"] for v in variants):
            chosen = next(v for v in variants if v[0] == snap["mode"])
        else:
            chosen = max(variants, key=lambda v: (v[3]["value"], v[0] == "priority"))
        strat, plan, issues, q = chosen
        conflicts = []
        for c in detected[:40]:
            conflicts.append({**c, "at": r1(c["at"]), "time": hhmm(c["at"]), "resolution": resolve_text(c, plan, self.topo)})
        recs = recommendations(plan, self.spec_by_id, self.topo, now, horizon)
        for rc in recs:
            rc["until_hhmm"] = hhmm(rc["until"])
        payload = {
            "type": "plan", "sim_t": r1(now), "reason": snap["reason"], "mode": snap["mode"],
            "strategy": strat, "strategy_label": STRATEGY_LABELS.get(strat, strat),
            "trains": {tid: {"legs": [[lg.st, r1(lg.arr), r1(lg.dep), lg.stop, r1(lg.wait)] for lg in tp.legs],
                             "delay_min": round(tp.delay / 60, 1)} for tid, tp in plan.trains.items()},
            "variants": [{"strategy": s, "label": STRATEGY_LABELS.get(s, s), "hint": STRATEGY_HINTS.get(s, ""),
                          "index": vq["value"], "letter": vq["letter"], "category": vq["category"],
                          "total_delay_min": vq["total_delay_min"], "avg_delay_min": vq["avg_delay_min"],
                          "unresolved": len(vi), "active": s == strat} for s, _, vi, vq in variants],
            "conflicts": conflicts,
            "unresolved": issues,
            "recommendations": recs[:40],
            "quality": q,
            "alerts": self._alerts(now, plan, conflicts, issues, q, snap["incidents"]),
        }
        payload["compute_ms"] = round((time.perf_counter() - t0) * 1000, 1)
        return plan, payload

    def _alerts(self, now: float, plan, conflicts: list, issues: list, q: dict, incidents: list) -> list:
        al = []
        for i in issues:
            al.append({"level": "critical", "title": "Нерешённый конфликт в плане",
                       "text": f"{', '.join(i['trains'])}: требуется решение диспетчера", "at": r1(i["at"])})
        for inc in incidents:
            lvl = "critical" if inc["type"] == "closure" else "warning"
            al.append({"level": lvl, "title": INCIDENT_LABELS[inc["type"]], "text": inc["text"], "at": r1(inc["start"])})
        if q["category"] == "critical":
            al.append({"level": "critical", "title": "Индекс качества: «Критично»",
                       "text": q["factors"][0]["detail"] if q["factors"] else "", "at": r1(now)})
        for c in conflicts:
            if c["at"] - now <= 30 * 60:
                al.append({"level": "warning", "title": c["title"],
                           "text": f"{' / '.join(c['trains'])}, {c['where']}, {c['time']} → {c['resolution']}", "at": c["at"]})
        for tid, tp in plan.trains.items():
            if tp.delay >= 10 * 60:
                al.append({"level": "info", "title": f"Опоздание {tid}",
                           "text": f"Прогноз на конечной: +{tp.delay / 60:.0f} мин", "at": r1(now)})
        rank = {"critical": 0, "warning": 1, "info": 2}
        al.sort(key=lambda a: (rank[a["level"]], a["at"] or 0))
        return al[:30]

    # ---------- нештатные ситуации ----------
    def add_incident(self, kind: str, minutes: float, train_id: str | None = None,
                     segment_id: str | None = None, source: str = "dispatcher") -> dict:
        now = self.sim_now()
        if kind not in INCIDENT_LABELS:
            raise ValueError("Неизвестный тип ситуации")
        if not (1 <= minutes <= 240):
            raise ValueError("Длительность должна быть от 1 до 240 минут")
        iid = uuid.uuid4().hex[:8]
        end = now + minutes * 60
        inc = {"id": iid, "type": kind, "label": INCIDENT_LABELS[kind], "minutes": minutes, "start": now, "end": end,
               "active": True, "train_id": train_id, "segment_id": segment_id, "segment_idx": None, "source": source}
        if kind == "delay":
            if not train_id or not self.world.apply_delay(train_id, end):
                raise ValueError("Поезд не найден на участке")
            inc["text"] = f"{train_id} задержан на {minutes:.0f} мин"
        else:
            seg = self.topo.seg_by_id.get(segment_id or "")
            if not seg:
                raise ValueError("Перегон не найден")
            inc["segment_idx"] = seg.idx
            for other in self.incidents.values():   # повторное внесение продлевает действующую ситуацию
                if other["active"] and other["type"] == kind and other["segment_idx"] == seg.idx:
                    other["end"] = max(other["end"], end)
                    other["minutes"] = round((other["end"] - other["start"]) / 60)
                    other["text"] = other["text"].rsplit(" до ", 1)[0] + f" до {hhmm(other['end'])}"
                    (self.world.set_closure(seg.idx, other["end"]) if kind == "closure"
                     else self.world.set_limit(seg.idx, SIGNAL_FAULT_KMH, other["end"]))
                    self.storage.add_event(now, "incident", "warning", f"Продлено: {other['text']}", other)
                    self.request_replan("incident")
                    return other
            name = f"{self.topo.stations[seg.a].name} — {self.topo.stations[seg.b].name}"
            if kind == "closure":
                self.world.set_closure(seg.idx, end)
                inc["text"] = f"Перегон {name} закрыт до {hhmm(end)}"
            else:
                self.world.set_limit(seg.idx, SIGNAL_FAULT_KMH, end)
                inc["text"] = f"Неисправность сигнала на перегоне {name}: ограничение {SIGNAL_FAULT_KMH} км/ч до {hhmm(end)}"
        self.incidents[iid] = inc
        self.metrics.inc("incidents")
        self.storage.add_event(now, "incident", "warning", inc["text"], inc)
        self.request_replan("incident")
        return inc

    def resolve_incident(self, iid: str) -> dict:
        inc = self.incidents.get(iid)
        if not inc:
            raise KeyError(iid)
        if inc["active"]:
            inc["active"] = False
            inc["end"] = self.sim_now()
            self.world.clear(inc["type"], inc["segment_idx"], inc["train_id"])
            self.storage.add_event(self.sim_now(), "incident", "info", f"Снято: {inc['text']}", inc)
            self.request_replan("incident")
        return inc

    def storm(self, count: int) -> list:
        rng = random.Random()
        active = [t for t, w in self.world.trains.items() if w.status in ("running", "dwell", "pending")]
        created = []
        closure_used = any(i["active"] and i["type"] == "closure" for i in self.incidents.values())
        for _ in range(count):
            r = rng.random()
            try:
                if r < 0.6 and active:
                    created.append(self.add_incident("delay", rng.randint(3, 12), train_id=rng.choice(active), source="storm"))
                elif r < 0.9 or closure_used:
                    created.append(self.add_incident("signal_fault", rng.randint(10, 25),
                                                     segment_id=rng.choice(self.topo.segments).id, source="storm"))
                else:
                    closure_used = True
                    created.append(self.add_incident("closure", 15, segment_id=rng.choice(self.topo.segments).id, source="storm"))
            except ValueError:
                continue
        return created

    def _expire_incidents(self, now: float) -> None:
        for inc in self.incidents.values():
            if inc["active"] and now >= inc["end"]:
                inc["active"] = False
                self.storage.add_event(now, "incident", "info", f"Завершено: {inc['text']}", inc)
                self.request_replan("incident")

    def set_mode(self, strategy: str) -> None:
        if strategy != "auto" and strategy not in self.cfg["dispatcher"]["strategies"]:
            raise ValueError("Неизвестная стратегия")
        self.mode = strategy
        label = "автоматический выбор" if strategy == "auto" else STRATEGY_LABELS.get(strategy, strategy)
        self.storage.add_event(self.sim_now(), "apply", "info", f"Диспетчер выбрал вариант: {label}")
        self.request_replan("apply")

    # ---------- данные для клиентов ----------
    def _record_traces(self, now: float) -> None:
        for tid, r in self.state.trains.items():
            if r["status"] in ("running", "dwell"):
                tr = self.traces[tid]
                if not tr or now - tr[-1][0] >= 20 or (r["status"] == "running" and now - tr[-1][0] >= 10):
                    tr.append([round(now, 1), round(r["km"], 3)])
        if int(now) % 600 < 5:
            cutoff = now - 6 * 3600
            for tid in list(self.traces):
                tr = self.traces[tid]
                if tr and tr[-1][0] < cutoff:
                    del self.traces[tid]

    def tick_payload(self, now: float) -> dict:
        trains = []
        plan_trains = self.result.get("trains", {})
        holds = self._holds(now)
        for tid, r in self.state.trains.items():
            if r["status"] == "done":
                continue
            spec = self.spec_by_id.get(tid)
            trains.append({
                "id": tid, "cat": r.get("category") or (spec.category if spec else ""), "dir": r["direction"],
                "status": r["status"], "st": r["station"], "seg": r["segment"], "km": r["km"], "v": r["speed_kmh"],
                "delay": plan_trains.get(tid, {}).get("delay_min", 0.0), "hold": holds.get(tid, 0) > now,
            })
        q = self.result.get("quality") or {}
        c = self.metrics.counters
        return {
            "type": "tick", "sim_t": round(now, 1), "clock": hhmm(now), "trains": trains,
            "signals": self.state.signals, "switches": self.state.switches,
            "incidents": [i for i in self.incidents.values() if i["active"]],
            "index": {"value": q.get("value"), "letter": q.get("letter"), "category": q.get("category")},
            "feed": {"rate": self.metrics.msg_rate(), "age_s": round(time.monotonic() - self.last_feed_real, 1),
                     "received": c.get("messages_received", 0), "duplicates": c.get("messages_duplicate", 0),
                     "invalid": c.get("messages_invalid", 0), "out_of_order": c.get("messages_out_of_order", 0)},
        }

    def graph(self, before_min: float = 90, after_min: float = 150) -> dict:
        now = self.sim_now()
        t_from, t_to = now - before_min * 60, now + after_min * 60
        st_km = [s.km for s in self.topo.stations]
        cats = {}
        traces = {}
        for tid, tr in self.traces.items():
            pts = [p for p in tr if p[0] >= t_from]
            if pts:
                traces[tid] = pts
                if tid in self.spec_by_id:
                    cats[tid] = self.spec_by_id[tid].category
        plan_pts = {}
        if self.plan:
            for tid, tp in self.plan.trains.items():
                pts = []
                r = self.state.trains.get(tid)
                if r and r["status"] == "running":
                    pts.append([round(now, 1), r["km"]])
                for lg in tp.legs:
                    if lg.arr is not None:
                        pts.append([round(lg.arr, 1), st_km[lg.st]])
                    if lg.dep is not None:
                        pts.append([round(lg.dep, 1), st_km[lg.st]])
                if pts and pts[0][0] <= t_to:
                    plan_pts[tid] = pts
                    cats[tid] = self.spec_by_id[tid].category
        nominal = {}
        for s in self.specs:
            dep, arr = s.sched_dep_origin(), s.sched_arr_terminal() or 0
            if arr < t_from or dep > t_to:
                continue
            pts = []
            for st in s.path:
                a, d = s.sched.get(st, (None, None))
                if a is not None:
                    pts.append([round(a, 1), st_km[st]])
                if d is not None:
                    pts.append([round(d, 1), st_km[st]])
            nominal[s.id] = pts
            cats.setdefault(s.id, s.category)
        closures = []
        for inc in self.incidents.values():
            if inc["type"] in ("closure", "signal_fault") and inc["segment_idx"] is not None and inc["end"] >= t_from:
                seg = self.topo.segments[inc["segment_idx"]]
                closures.append({"type": inc["type"], "from_km": st_km[seg.a], "to_km": st_km[seg.b],
                                 "start": inc["start"], "end": inc["end"], "active": inc["active"]})
        return {"now": now, "from": t_from, "to": t_to, "traces": traces, "plan": plan_pts, "nominal": nominal,
                "categories": cats, "closures": closures, "conflicts": self.result.get("conflicts", [])}

    def ato_advice(self, tid: str) -> dict:
        r = self.state.trains.get(tid)
        spec = self.spec_by_id.get(tid)
        if not r or not spec or r["status"] == "done":
            raise KeyError(tid)
        cat = self.cats[spec.category]
        tp = self.plan.trains.get(tid) if self.plan else None
        now = self.sim_now()
        if r["status"] == "running":
            seg = self.topo.segments[r["segment"]]
            start_st = self.topo.seg_start(seg, spec.direction)
            t_begin = r.get("enter_time", now)
            lg0 = tp.leg_at(start_st) if tp else None
            stop_start = start_st in spec.stops or bool(lg0 and lg0.stop) or r.get("speed_kmh", 0) < 1
        else:
            start_st = r["station"]
            seg = self.topo.seg_from(start_st, spec.direction)
            if seg is None:
                raise KeyError(tid)
            lg0 = tp.leg_at(start_st) if tp else None
            t_begin = lg0.dep if lg0 and lg0.dep else now
            stop_start = True
        end_st = self.topo.seg_end(seg, spec.direction)
        lg1 = tp.leg_at(end_st) if tp else None
        stop_end = end_st in spec.stops or end_st == spec.terminal or bool(lg1 and lg1.stop)
        vlim = min(seg.vmax_kmh, self.world.vlim(seg.idx))
        vp = min(cat.vmax_kmh, vlim) * ato.KMH
        vs, ve = (0.0 if stop_start else vp), (0.0 if stop_end else vp)
        fast = ato.fastest(seg.length_m, vs, ve, cat.dyn, vlim)
        target = (lg1.arr - t_begin) if lg1 and lg1.arr else fast.total_time * float(self.cfg["dispatcher"]["runtime_margin"])
        prof = ato.optimal(seg.length_m, vs, ve, target, cat.dyn, vlim)
        start_km = self.topo.stations[start_st].km
        to_km = lambda x: round(start_km + spec.direction * x / 1000, 3)  # noqa: E731
        rec = ato.recommendation(prof, fast)
        cur = None
        if r["status"] == "running":
            x = abs(r["km"] - start_km) * 1000
            v_rec = prof.speed_at(min(x, seg.length_m)) / ato.KMH
            delta = r["speed_kmh"] - v_rec
            if abs(delta) <= 5:
                hint = "Режим соответствует рекомендации"
            elif delta > 0:
                hint = f"Снизить скорость на {delta:.0f} км/ч — время хода позволяет экономить энергию"
            else:
                hint = f"Увеличить скорость на {-delta:.0f} км/ч, чтобы прибыть по плану"
            acc_end = prof.d_acc
            if x < acc_end and delta < 0:
                hint = f"Разгон до {rec['cruise_kmh']:.0f} км/ч, затем держать скорость"
            if x >= rec["brake_from_m"]:
                hint = "Служебное торможение к станции"
            if x >= rec["coast_from_m"] and x < rec["brake_from_m"]:
                hint = "Выбег: отключить тягу" + ("" if abs(delta) <= 8 else f" ({hint.lower()})")
            cur = {"km": r["km"], "speed_kmh": r["speed_kmh"], "recommended_kmh": round(v_rec, 1), "hint": hint}
        return {
            "train_id": tid, "category": spec.category, "status": r["status"],
            "from": self.topo.stations[start_st].name, "to": self.topo.stations[end_st].name,
            "from_km": start_km, "to_km": self.topo.stations[end_st].km, "vlimit_kmh": vlim,
            "profile": [[to_km(x), v] for x, v in prof.samples()],
            "fastest": [[to_km(x), v] for x, v in fast.samples()],
            "allotted_s": round(target), "arrival": hhmm(t_begin + prof.total_time),
            "planned_arrival": hhmm(lg1.arr) if lg1 and lg1.arr else None,
            "coast_from_km": to_km(rec["coast_from_m"]), "brake_from_km": to_km(rec["brake_from_m"]),
            **{k: rec[k] for k in ("cruise_kmh", "run_time_s", "energy_kwh", "energy_fastest_kwh", "saving_pct")},
            "phases": [{**p, "from_km": to_km(p["from_m"]), "to_km": to_km(p["to_m"])} for p in rec["phases"]],
            "current": cur,
        }

    def report(self, minutes: float) -> dict:
        now = self.sim_now()
        q = self.result.get("quality", {})
        return {
            "generated_sim": hhmm(now), "generated_real": time.strftime("%Y-%m-%d %H:%M:%S"),
            "section": self.topo.name, "minutes": minutes, "quality": q,
            "strategy": self.result.get("strategy_label"),
            "trains": sorted(({"id": t, "delay_min": v["delay_min"]} for t, v in self.result.get("trains", {}).items()),
                             key=lambda x: -x["delay_min"]),
            "incidents": [i for i in self.incidents.values() if i["end"] >= now - minutes * 60 * self.accel],
            "recommendations": self.result.get("recommendations", [])[:15],
            "conflicts": self.result.get("conflicts", [])[:15],
            "events": self.storage.events(minutes, 200),
            "quality_history": self.storage.quality(minutes),
            "metrics": self.metrics.summary(),
        }

    # ---------- WebSocket ----------
    async def broadcast(self, payload: dict) -> None:
        if not self.clients:
            return
        text = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
        dead = []
        for ws in list(self.clients):
            try:
                await asyncio.wait_for(ws.send_text(text), timeout=2)
            except Exception:  # noqa: BLE001
                dead.append(ws)
        for ws in dead:
            self.clients.discard(ws)
        self.metrics.set("ws_clients", len(self.clients))
