"""Генерация нормативного (бесконфликтного) графика движения из шаблона в конфигурации."""
from __future__ import annotations

from .dispatcher import Planner, TrainSpec
from .models import Category
from .topology import Topology


def generate(topo: Topology, cats: dict[str, Category], cfg: dict, start: float, hours: float) -> list[TrainSpec]:
    tt = cfg["timetable"]
    cycle = float(tt["cycle_min"]) * 60
    specs: list[TrainSpec] = []
    n_cycles = int(hours * 3600 // cycle) + 1
    first = int(start // cycle)
    for c in range(first, first + n_cycles):
        for p in tt["pattern"]:
            cat = cats[p["category"]]
            d = int(p["direction"])
            origin = 0 if d > 0 else len(topo.stations) - 1
            path = topo.path(origin, d)
            stops = {topo.by_id[s].idx for s in cat.stops if s in topo.by_id} | {path[0], path[-1]}
            number = int(p["number"]) + 10 * (c - first)
            dep = c * cycle + float(p["offset_min"]) * 60
            specs.append(TrainSpec(f"{cat.prefix}-{number}", cat.key, d, path, frozenset(stops), dep))
    # Нормативный график строится тем же планировщиком — он бесконфликтен по построению.
    planner = Planner(topo, cats, cfg["dispatcher"])
    plan = planner.plan(specs, {}, now=min(s.desired_dep for s in specs) - 1, strategy=cfg["timetable"].get("build_strategy", "timetable"))
    for s in specs:
        tp = plan.trains[s.id]
        s.sched = {lg.st: (lg.arr, lg.dep) for lg in tp.legs}
    specs.sort(key=lambda s: s.sched_dep_origin())
    return specs
