"""Модуль приёма и нормализации данных: валидация, дедупликация, упорядочивание, сглаживание."""
from __future__ import annotations

from collections import OrderedDict

from .metrics import Metrics
from .topology import Topology

TRAIN_STATUSES = {"pending", "dwell", "running", "done"}
SIGNAL_STATES = {"green", "red", "fault", "closed"}
SWITCH_STATES = {"normal", "reverse"}


class Ingestor:
    def __init__(self, topo: Topology, metrics: Metrics, alpha: float = 0.6, dedup_size: int = 20000):
        self.topo = topo
        self.m = metrics
        self.alpha = alpha
        self._seen: OrderedDict = OrderedDict()
        self._dedup_size = dedup_size
        self._last_seq: dict[str, int] = {}
        self._last: dict[str, dict] = {}

    def _dup(self, msg_id: str) -> bool:
        if msg_id in self._seen:
            return True
        self._seen[msg_id] = None
        if len(self._seen) > self._dedup_size:
            self._seen.popitem(last=False)
        return False

    def process(self, msg: dict, now: float) -> dict | None:
        self.m.inc("messages_received")
        if not isinstance(msg, dict) or "type" not in msg or "msg_id" not in msg or "ts" not in msg:
            self.m.inc("messages_invalid")
            return None
        if self._dup(str(msg["msg_id"])):
            self.m.inc("messages_duplicate")
            return None
        try:
            ts = float(msg["ts"])
        except (TypeError, ValueError):
            self.m.inc("messages_invalid")
            return None
        if abs(ts - now) > 3600:
            self.m.inc("messages_invalid")
            return None
        kind = msg["type"]
        if kind == "train":
            return self._train(msg, ts)
        if kind == "signal" and msg.get("state") in SIGNAL_STATES and msg.get("id"):
            self.m.inc("messages_accepted")
            return {"type": "signal", "id": msg["id"], "state": msg["state"], "ts": ts}
        if kind == "switch" and msg.get("state") in SWITCH_STATES and msg.get("id") in self.topo.by_id:
            self.m.inc("messages_accepted")
            return {"type": "switch", "id": msg["id"], "state": msg["state"], "ts": ts}
        self.m.inc("messages_invalid")
        return None

    def _train(self, msg: dict, ts: float) -> dict | None:
        tid = msg.get("train_id")
        status = msg.get("status")
        try:
            seq = int(msg["seq"])
            km = float(msg["km"])
            speed = float(msg["speed_kmh"])
            direction = int(msg["direction"])
        except (KeyError, TypeError, ValueError):
            self.m.inc("messages_invalid")
            return None
        if not tid or status not in TRAIN_STATUSES or direction not in (1, -1):
            self.m.inc("messages_invalid")
            return None
        if not (-0.5 <= km <= self.topo.length_km + 0.5) or not (0 <= speed <= 250):
            self.m.inc("messages_invalid")
            return None
        seg = msg.get("segment")
        st = msg.get("station")
        if status == "running" and seg not in self.topo.seg_by_id:
            self.m.inc("messages_invalid")
            return None
        if status in ("dwell", "pending", "done") and st not in self.topo.by_id:
            self.m.inc("messages_invalid")
            return None
        if seq <= self._last_seq.get(tid, -1):
            self.m.inc("messages_out_of_order")
            return None
        self._last_seq[tid] = seq
        prev = self._last.get(tid)
        if prev and prev["status"] == status == "running" and prev["segment"] == seg:
            a = self.alpha
            km_s = prev["km"] + a * (km - prev["km"])
            # монотонность: поезд не может двигаться назад
            km_s = max(km_s, prev["km"]) if direction > 0 else min(km_s, prev["km"])
            speed_s = prev["speed_kmh"] + a * (speed - prev["speed_kmh"])
        else:
            km_s, speed_s = km, speed
        out = {"type": "train", "train_id": tid, "category": msg.get("category"), "direction": direction,
               "status": status, "segment": seg, "station": st, "km": round(km_s, 3),
               "speed_kmh": round(max(0.0, speed_s), 1), "ts": ts, "seq": seq}
        self._last[tid] = out
        self.m.inc("messages_accepted")
        self.m.mark_message()
        return out
