"""Простые метрики сервиса в формате Prometheus (GET /metrics)."""
from __future__ import annotations

import threading
import time
from collections import deque


class Metrics:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self.counters: dict[str, float] = {}
        self.gauges: dict[str, float] = {}
        self.started = time.time()
        self._rate: deque = deque(maxlen=200)
        self.replan_ms: deque = deque(maxlen=100)
        self.latency_ms: deque = deque(maxlen=100)

    def inc(self, name: str, v: float = 1.0) -> None:
        with self._lock:
            self.counters[name] = self.counters.get(name, 0.0) + v

    def set(self, name: str, v: float) -> None:
        with self._lock:
            self.gauges[name] = v

    def mark_message(self) -> None:
        self._rate.append(time.monotonic())

    def msg_rate(self) -> float:
        now = time.monotonic()
        return sum(1 for t in self._rate if now - t < 1.0)

    @staticmethod
    def _p(values, q: float) -> float:
        if not values:
            return 0.0
        s = sorted(values)
        return s[min(len(s) - 1, int(q * len(s)))]

    def summary(self) -> dict:
        return {
            "uptime_s": round(time.time() - self.started),
            "counters": dict(self.counters),
            "gauges": dict(self.gauges),
            "replan_ms_p50": round(self._p(self.replan_ms, 0.5), 1),
            "replan_ms_p95": round(self._p(self.replan_ms, 0.95), 1),
            "update_latency_ms_p50": round(self._p(self.latency_ms, 0.5), 1),
            "update_latency_ms_p95": round(self._p(self.latency_ms, 0.95), 1),
        }

    def prometheus(self) -> str:
        lines = [f"autodispatcher_uptime_seconds {time.time() - self.started:.0f}"]
        with self._lock:
            for k, v in sorted(self.counters.items()):
                lines.append(f"autodispatcher_{k}_total {v:g}")
            for k, v in sorted(self.gauges.items()):
                lines.append(f"autodispatcher_{k} {v:g}")
        lines.append(f"autodispatcher_replan_ms_p95 {self._p(self.replan_ms, 0.95):.1f}")
        lines.append(f"autodispatcher_update_latency_ms_p95 {self._p(self.latency_ms, 0.95):.1f}")
        return "\n".join(lines) + "\n"
