"""Встроенная шина событий (in-process pub/sub).

Упрощённая замена Kafka/RabbitMQ: тот же контракт publish(topic, message) /
subscribe(topic) → очередь. Для промышленной версии реализация заменяется
адаптером к брокеру без изменения модулей-потребителей.
Топики: telemetry.raw, incident, plan.updated.
"""
from __future__ import annotations

import asyncio
from collections import defaultdict


class EventBus:
    def __init__(self) -> None:
        self._subs: dict[str, list[asyncio.Queue]] = defaultdict(list)
        self.published = 0
        self.dropped = 0

    def subscribe(self, topic: str, maxsize: int = 20000) -> asyncio.Queue:
        q: asyncio.Queue = asyncio.Queue(maxsize=maxsize)
        self._subs[topic].append(q)
        return q

    def publish(self, topic: str, message) -> None:
        self.published += 1
        for q in self._subs.get(topic, []):
            try:
                q.put_nowait(message)
            except asyncio.QueueFull:
                self.dropped += 1   # обратное давление: при переполнении буфера сообщение отбрасывается
