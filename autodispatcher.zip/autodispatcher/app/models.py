"""Параметры категорий поездов."""
from __future__ import annotations

from dataclasses import dataclass

from .ato import TrainDynamics


@dataclass(frozen=True)
class Category:
    key: str
    name: str
    prefix: str
    priority: int
    vmax_kmh: float
    dwell_s: float
    stops: tuple
    dyn: TrainDynamics


def load_categories(cfg: dict) -> dict[str, Category]:
    out = {}
    for key, c in cfg["categories"].items():
        out[key] = Category(
            key=key, name=c["name"], prefix=c["prefix"], priority=int(c["priority"]),
            vmax_kmh=float(c["vmax_kmh"]), dwell_s=float(c["dwell_min"]) * 60, stops=tuple(c.get("stops", [])),
            dyn=TrainDynamics(float(c["vmax_kmh"]), float(c["accel"]), float(c["brake"]),
                              float(c["coast"]), float(c["mass_t"])),
        )
    return out
