"""Топология участка: станции, разъезды, перегоны."""
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Station:
    idx: int
    id: str
    name: str
    km: float
    tracks: int
    kind: str


@dataclass(frozen=True)
class Segment:
    idx: int
    id: str
    a: int          # индекс станции с меньшим километражом
    b: int          # индекс станции с большим километражом
    length_m: float
    vmax_kmh: float


class Topology:
    def __init__(self, data: dict):
        self.name = data["name"]
        self.stations = [Station(i, s["id"], s["name"], float(s["km"]), int(s["tracks"]), s["kind"])
                         for i, s in enumerate(data["stations"])]
        self.by_id = {s.id: s for s in self.stations}
        self.segments = []
        for i in range(len(self.stations) - 1):
            a, b = self.stations[i], self.stations[i + 1]
            vmax = float(data["segments"][i]["vmax_kmh"])
            self.segments.append(Segment(i, f"{a.id}-{b.id}", i, i + 1, (b.km - a.km) * 1000.0, vmax))
        self.seg_by_id = {s.id: s for s in self.segments}

    @classmethod
    def load(cls, path: Path) -> "Topology":
        with open(path, encoding="utf-8") as f:
            return cls(json.load(f))

    @property
    def length_km(self) -> float:
        return self.stations[-1].km

    def seg_from(self, st: int, direction: int) -> Segment | None:
        k = st if direction > 0 else st - 1
        return self.segments[k] if 0 <= k < len(self.segments) else None

    def seg_end(self, seg: Segment, direction: int) -> int:
        return seg.b if direction > 0 else seg.a

    def seg_start(self, seg: Segment, direction: int) -> int:
        return seg.a if direction > 0 else seg.b

    def path(self, origin: int, direction: int) -> list[int]:
        if direction > 0:
            return list(range(origin, len(self.stations)))
        return list(range(origin, -1, -1))

    def km_at(self, seg_idx: int, x_m: float, direction: int) -> float:
        seg = self.segments[seg_idx]
        if direction > 0:
            return self.stations[seg.a].km + x_m / 1000.0
        return self.stations[seg.b].km - x_m / 1000.0

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "length_km": self.length_km,
            "stations": [s.__dict__ for s in self.stations],
            "segments": [s.__dict__ for s in self.segments],
        }
