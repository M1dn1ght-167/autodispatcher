"""Текущее состояние участка (последние нормализованные данные)."""
from __future__ import annotations

from .topology import Topology


class StateStore:
    def __init__(self, topo: Topology):
        self.topo = topo
        self.trains: dict[str, dict] = {}
        self.signals: dict[str, str] = {}
        self.switches: dict[str, str] = {}
        self.last_message_ts = 0.0

    def apply(self, m: dict) -> bool:
        """Возвращает True, если изменилось «дискретное» состояние (повод для пересчёта плана)."""
        self.last_message_ts = max(self.last_message_ts, m["ts"])
        if m["type"] == "signal":
            changed = self.signals.get(m["id"]) != m["state"]
            self.signals[m["id"]] = m["state"]
            return changed and m["state"] in ("fault", "closed")
        if m["type"] == "switch":
            self.switches[m["id"]] = m["state"]
            return False
        tid = m["train_id"]
        cur = self.trains.get(tid)
        st_idx = self.topo.by_id[m["station"]].idx if m.get("station") else None
        seg_idx = self.topo.seg_by_id[m["segment"]].idx if m.get("segment") else None
        transition = cur is None or cur["status"] != m["status"] or cur["station"] != st_idx or cur["segment"] != seg_idx
        rec = cur or {}
        rec.update({k: m[k] for k in ("train_id", "category", "direction", "status", "km", "speed_kmh", "ts")})
        rec["station"], rec["segment"] = st_idx, seg_idx
        if transition:
            if m["status"] == "running":
                rec["enter_time"] = m["ts"]
            elif m["status"] in ("dwell", "pending"):
                rec["arr_time"] = m["ts"]
        self.trains[tid] = rec
        return transition

    def prune(self, now: float, keep_s: float = 3600) -> None:
        for tid in [t for t, r in self.trains.items() if r["status"] == "done" and now - r["ts"] > keep_s]:
            del self.trains[tid]
