"""Симулятор движения поездов по участку («реальный мир» для демо).

Поезда следуют рекомендациям текущего плана (диспетчер их принимает) и профилям
автоведения. Простая модель централизации не допускает выезда на перегон,
занятый встречным поездом, и сближения попутных поездов (имитация СЦБ).
Телеметрия выдаётся с шумом, дублями, перестановками и битыми сообщениями —
чтобы проверить модуль приёма данных.
"""
from __future__ import annotations

import random
import uuid
from dataclasses import dataclass, field

from . import ato
from .dispatcher import TrainSpec
from .models import Category
from .topology import Topology

BLOCK_M = 3000.0


@dataclass
class WorldTrain:
    spec: TrainSpec
    status: str = "pending"
    station: int | None = None
    seg: int | None = None
    x: float = 0.0
    x0: float = 0.0
    t0: float = 0.0
    profile: ato.SpeedProfile | None = None
    enter_t: float = 0.0
    arr_t: float = 0.0
    hold_until: float = 0.0
    speed: float = 0.0
    end_stop: bool = True
    frozen: bool = False
    done_t: float = 0.0
    seq: int = 0
    next_emit: float = 0.0
    delay_rolled: set = field(default_factory=set)


class World:
    def __init__(self, topo: Topology, cats: dict[str, Category], specs: list[TrainSpec], cfg: dict):
        self.topo = topo
        self.cats = cats
        self.cfg = cfg
        s = cfg["simulation"]
        self.rng = random.Random(int(s.get("seed", 7)))
        self.specs = sorted(specs, key=lambda sp: sp.sched_dep_origin())
        self.ptr = 0
        self.trains: dict[str, WorldTrain] = {}
        self.closed: dict[int, float] = {}
        self.limits: dict[int, tuple[float, float]] = {}
        self.signals: dict[str, str] = {}
        self.switches: dict[str, str] = {}
        self._reorder: list = []
        self.headway = float(cfg["dispatcher"]["headway_min"]) * 60
        self.margin = float(cfg["dispatcher"]["runtime_margin"])
        self.emit_every_sim = float(s["emit_interval_s"]) * float(s["accel"])
        self.random_delays = True

    # ---------- нештатные ситуации ----------
    def apply_delay(self, train_id: str, until: float) -> bool:
        wt = self.trains.get(train_id)
        if not wt or wt.status == "done":
            return False
        wt.hold_until = max(wt.hold_until, until)
        return True

    def set_closure(self, seg: int, until: float) -> None:
        self.closed[seg] = until

    def set_limit(self, seg: int, kmh: float, until: float) -> None:
        self.limits[seg] = (kmh, until)

    def clear(self, kind: str, seg: int | None = None, train_id: str | None = None) -> None:
        if kind == "closure" and seg is not None:
            self.closed.pop(seg, None)
        elif kind == "signal_fault" and seg is not None:
            self.limits.pop(seg, None)
        elif kind == "delay" and train_id in self.trains:
            self.trains[train_id].hold_until = 0.0

    def vlim(self, seg: int) -> float:
        lim = self.limits.get(seg)
        v = self.topo.segments[seg].vmax_kmh
        return min(v, lim[0]) if lim else v

    # ---------- шаг моделирования ----------
    def step(self, now: float, plan_trains: dict) -> None:
        for seg, until in list(self.closed.items()):
            if now >= until:
                del self.closed[seg]
        for seg, (_, until) in list(self.limits.items()):
            if now >= until:
                del self.limits[seg]
        lead = float(self.cfg["simulation"]["spawn_lead_min"]) * 60
        while self.ptr < len(self.specs) and self.specs[self.ptr].sched_dep_origin() - lead <= now:
            sp = self.specs[self.ptr]
            self.ptr += 1
            if sp.sched_dep_origin() < now - 600:
                continue
            self.trains[sp.id] = WorldTrain(sp, status="pending", station=sp.origin, arr_t=now, next_emit=now)
        order = sorted(self.trains.values(), key=lambda w: -self.cats[w.spec.category].priority)
        for wt in order:
            if wt.status == "done":
                if now - wt.done_t > 120:
                    del self.trains[wt.spec.id]
                continue
            if wt.status in ("pending", "dwell"):
                self._try_depart(wt, now, plan_trains)
            elif wt.status == "running":
                self._advance(wt, now, plan_trains)

    def _planned_dep(self, wt: WorldTrain, st: int, plan_trains: dict) -> float | None:
        tp = plan_trains.get(wt.spec.id)
        if tp:
            lg = tp.leg_at(st)
            if lg and lg.dep is not None:
                return lg.dep
        return wt.spec.sched.get(st, (None, None))[1]

    def _try_depart(self, wt: WorldTrain, now: float, plan_trains: dict) -> None:
        spec = wt.spec
        if now < wt.hold_until:
            return
        st = wt.station
        if wt.status == "dwell" and st in spec.stops and now < wt.arr_t + self.cats[spec.category].dwell_s:
            return
        dep = self._planned_dep(wt, st, plan_trains)
        if dep is not None and now + 0.01 < dep:
            return
        seg = self.topo.seg_from(st, spec.direction)
        if seg is None or not self._can_enter(seg.idx, spec.direction, wt, now):
            return
        rd = self.cfg["simulation"]["random_delays"]
        if self.random_delays and st not in wt.delay_rolled:
            wt.delay_rolled.add(st)
            if self.rng.random() < float(rd["prob_per_departure"]):
                wt.hold_until = now + self.rng.uniform(1, float(rd["max_min"])) * 60
                return
        self._start_segment(wt, seg.idx, now, 0.0, plan_trains)

    def _start_segment(self, wt: WorldTrain, seg_idx: int, now: float, vs: float, plan_trains: dict) -> None:
        spec, cat = wt.spec, self.cats[wt.spec.category]
        seg = self.topo.segments[seg_idx]
        nxt = self.topo.seg_end(seg, spec.direction)
        tp = plan_trains.get(spec.id)
        lg = tp.leg_at(nxt) if tp else None
        end_stop = nxt == spec.terminal or nxt in spec.stops or bool(lg and lg.stop)
        vlim = self.vlim(seg_idx)
        vp = min(cat.vmax_kmh, vlim) * ato.KMH
        ve = 0.0 if end_stop else vp
        vs = min(vs, vp)
        fast = ato.fastest(seg.length_m, vs, ve, cat.dyn, vlim)
        target = fast.total_time * self.margin
        if lg and lg.arr is not None:
            target = max(fast.total_time, lg.arr - now)
        target *= self.rng.uniform(0.99, 1.025)      # «человеческий фактор» машиниста
        wt.profile = ato.optimal(seg.length_m, vs, ve, target, cat.dyn, vlim, step_kmh=4)
        wt.status, wt.seg, wt.station = "running", seg_idx, None
        wt.x = wt.x0 = 0.0
        wt.t0 = wt.enter_t = now
        wt.end_stop = end_stop
        wt.frozen = False

    def _leader_gap(self, wt: WorldTrain) -> float | None:
        gap = None
        for o in self.trains.values():
            if o is wt or o.status != "running" or o.seg != wt.seg or o.spec.direction != wt.spec.direction:
                continue
            if o.x > wt.x:
                g = o.x - wt.x
                gap = g if gap is None else min(gap, g)
        return gap

    def _advance(self, wt: WorldTrain, now: float, plan_trains: dict) -> None:
        seg = self.topo.segments[wt.seg]
        cat = self.cats[wt.spec.category]
        if now < wt.hold_until:
            wt.speed, wt.frozen = 0.0, True
            return
        gap = self._leader_gap(wt)
        if wt.frozen:
            if gap is not None and gap < BLOCK_M:
                return
            rem = max(1.0, seg.length_m - wt.x)
            vlim = self.vlim(wt.seg)
            ve = 0.0 if wt.end_stop else min(cat.vmax_kmh, vlim) * ato.KMH
            fast = ato.fastest(rem, 0.0, ve, cat.dyn, vlim)
            wt.profile = ato.optimal(rem, 0.0, ve, fast.total_time * self.margin, cat.dyn, vlim, step_kmh=4)
            wt.x0, wt.t0, wt.frozen = wt.x, now, False
        if gap is not None and gap < BLOCK_M * 0.6:
            wt.speed, wt.frozen = 0.0, True
            return
        x, v = wt.profile.state_at(now - wt.t0)
        wt.x = min(seg.length_m, wt.x0 + x)
        wt.speed = v
        if now - wt.t0 >= wt.profile.total_time:
            self._arrive(wt, now, plan_trains)

    def _arrive(self, wt: WorldTrain, now: float, plan_trains: dict) -> None:
        spec = wt.spec
        seg = self.topo.segments[wt.seg]
        st = self.topo.seg_end(seg, spec.direction)
        v_in = wt.speed
        wt.station, wt.seg, wt.x = st, None, 0.0
        if st == spec.terminal:
            wt.status, wt.done_t, wt.speed = "done", now, 0.0
            return
        if not wt.end_stop:
            nseg = self.topo.seg_from(st, spec.direction)
            dep = self._planned_dep(wt, st, plan_trains)
            if (dep is None or dep <= now + 20) and now >= wt.hold_until and self._can_enter(nseg.idx, spec.direction, wt, now):
                self._start_segment(wt, nseg.idx, now, v_in, plan_trains)
                return
        wt.status, wt.arr_t, wt.speed = "dwell", now, 0.0

    def _can_enter(self, seg: int, direction: int, wt: WorldTrain, now: float) -> bool:
        if seg in self.closed:
            return False
        for o in self.trains.values():
            if o is wt or o.status != "running" or o.seg != seg:
                continue
            if o.spec.direction != direction:
                return False
            if o.x < BLOCK_M or now - o.enter_t < self.headway * 0.5:
                return False
        return True

    # ---------- телеметрия ----------
    def _signal_states(self, now: float) -> dict:
        out = {}
        for st in self.topo.stations:
            for d in (1, -1):
                seg = self.topo.seg_from(st.idx, d)
                if seg is None:
                    continue
                key = f"{st.id}:{'odd' if d > 0 else 'even'}"
                if seg.idx in self.limits:
                    out[key] = "fault"
                elif seg.idx in self.closed:
                    out[key] = "closed"
                else:
                    busy = any(o.status == "running" and o.seg == seg.idx and
                               (o.spec.direction != d or o.x < BLOCK_M) for o in self.trains.values())
                    out[key] = "red" if busy else "green"
        return out

    def telemetry(self, now: float) -> list[dict]:
        nz = self.cfg["simulation"]["noise"]
        rng = self.rng
        msgs: list[dict] = []
        if self._reorder and rng.random() < 0.5:
            msgs.append(self._reorder.pop(0))
        for wt in self.trains.values():
            if now < wt.next_emit:
                continue
            wt.next_emit = now + self.emit_every_sim
            wt.seq += 1
            if wt.status == "running":
                km = self.topo.km_at(wt.seg, wt.x, wt.spec.direction)
            else:
                km = self.topo.stations[wt.station].km
            msg = {
                "type": "train", "msg_id": uuid.uuid4().hex, "seq": wt.seq, "ts": now,
                "train_id": wt.spec.id, "category": wt.spec.category, "direction": wt.spec.direction,
                "status": wt.status,
                "station": self.topo.stations[wt.station].id if wt.station is not None else None,
                "segment": self.topo.segments[wt.seg].id if wt.seg is not None else None,
                "km": round(km + (rng.gauss(0, float(nz["km_sigma"])) if wt.status == "running" else 0.0), 3),
                "speed_kmh": round(max(0.0, wt.speed / ato.KMH + (rng.gauss(0, float(nz["speed_sigma"])) if wt.speed > 0 else 0.0)), 1),
            }
            r = rng.random()
            if r < float(nz["invalid_prob"]):
                bad = dict(msg, msg_id=uuid.uuid4().hex, km=-999.0)
                msgs.append(bad)
            if r < float(nz["reorder_prob"]) and wt.seq > 2:
                self._reorder.append(dict(msg, seq=wt.seq - 2, msg_id=uuid.uuid4().hex))
            msgs.append(msg)
            if rng.random() < float(nz["duplicate_prob"]):
                msgs.append(dict(msg))
        sig = self._signal_states(now)
        for key, state in sig.items():
            if self.signals.get(key) != state:
                st, d = key.split(":")
                msgs.append({"type": "signal", "msg_id": uuid.uuid4().hex, "ts": now, "id": key,
                             "station": st, "direction": d, "state": state})
        self.signals = sig
        for st in self.topo.stations:
            n = sum(1 for o in self.trains.values() if o.status in ("dwell", "pending") and o.station == st.idx)
            state = "reverse" if n >= 2 else "normal"
            if self.switches.get(st.id) != state:
                msgs.append({"type": "switch", "msg_id": uuid.uuid4().hex, "ts": now, "id": st.id, "state": state})
                self.switches[st.id] = state
        return msgs
