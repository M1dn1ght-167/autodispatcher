"""Модуль автоведения (advisory ATO).

Рассчитывает рекомендуемый профиль скорости на перегоне: разгон → движение с
постоянной скоростью → выбег (без тяги) → торможение. Среди всех профилей,
укладывающихся в отведённое планом время хода, выбирается профиль
с минимальным расходом энергии на тягу. Это рекомендация машинисту,
а не команда управления поездом.

Модель (упрощённая, для прототипа):
  * разгон с постоянным ускорением a, торможение с постоянным замедлением b;
  * на выбеге поезд замедляется с постоянным замедлением c (сопротивление движению);
  * работа тяги:  W = m·(v_c² − v_0²)/2 + m·c·(s_разгон + s_ход),  E = W / η.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

KMH = 1 / 3.6


@dataclass(frozen=True)
class TrainDynamics:
    vmax_kmh: float
    accel: float
    brake: float
    coast: float
    mass_t: float
    efficiency: float = 0.85


@dataclass
class SpeedProfile:
    length_m: float
    v_start: float
    v_end: float
    v_cruise: float
    v_coast_end: float
    d_acc: float
    d_cruise: float
    d_coast: float
    d_brake: float
    t_acc: float
    t_cruise: float
    t_coast: float
    t_brake: float
    energy_kwh: float
    dyn: TrainDynamics

    @property
    def total_time(self) -> float:
        return self.t_acc + self.t_cruise + self.t_coast + self.t_brake

    def state_at(self, t: float) -> tuple[float, float]:
        """Положение (м от начала) и скорость (м/с) через t секунд после начала профиля."""
        a, b, c = self.dyn.accel, self.dyn.brake, self.dyn.coast
        if t <= 0:
            return 0.0, self.v_start
        if t < self.t_acc:
            return self.v_start * t + 0.5 * a * t * t, self.v_start + a * t
        t -= self.t_acc
        x0 = self.d_acc
        if t < self.t_cruise:
            return x0 + self.v_cruise * t, self.v_cruise
        t -= self.t_cruise
        x0 += self.d_cruise
        if t < self.t_coast:
            return x0 + self.v_cruise * t - 0.5 * c * t * t, self.v_cruise - c * t
        t -= self.t_coast
        x0 += self.d_coast
        if t < self.t_brake:
            v1 = self.v_coast_end
            return x0 + v1 * t - 0.5 * b * t * t, max(self.v_end, v1 - b * t)
        return self.length_m, self.v_end

    def speed_at(self, x: float) -> float:
        a, b, c = self.dyn.accel, self.dyn.brake, self.dyn.coast
        if x < self.d_acc:
            return math.sqrt(self.v_start ** 2 + 2 * a * x)
        x -= self.d_acc
        if x < self.d_cruise:
            return self.v_cruise
        x -= self.d_cruise
        if x < self.d_coast:
            return math.sqrt(max(0.0, self.v_cruise ** 2 - 2 * c * x))
        x -= self.d_coast
        return math.sqrt(max(self.v_end ** 2, self.v_coast_end ** 2 - 2 * b * x))

    def samples(self, n: int = 80) -> list[list[float]]:
        pts = []
        for i in range(n + 1):
            x = self.length_m * i / n
            pts.append([round(x, 1), round(self.speed_at(x) / KMH, 1)])
        return pts

    def phases(self) -> list[dict]:
        out, x = [], 0.0
        for name, d, t in (("Разгон", self.d_acc, self.t_acc), ("Ход с постоянной скоростью", self.d_cruise, self.t_cruise),
                           ("Выбег (без тяги)", self.d_coast, self.t_coast), ("Торможение", self.d_brake, self.t_brake)):
            if d > 1:
                out.append({"phase": name, "from_m": round(x), "to_m": round(x + d), "duration_s": round(t)})
            x += d
        return out


def _build(length: float, vs: float, ve: float, vc: float, v1: float, dyn: TrainDynamics) -> SpeedProfile | None:
    a, b, c = dyn.accel, dyn.brake, dyn.coast
    d_acc = (vc * vc - vs * vs) / (2 * a)
    d_coast = (vc * vc - v1 * v1) / (2 * c)
    d_brake = (v1 * v1 - ve * ve) / (2 * b)
    d_cruise = length - d_acc - d_coast - d_brake
    if d_acc < -1e-6 or d_cruise < -1e-3 or v1 < ve - 1e-6:
        return None
    d_cruise = max(0.0, d_cruise)
    m = dyn.mass_t * 1000.0
    work = m * ((vc * vc - vs * vs) / 2 + c * (d_acc + d_cruise))
    return SpeedProfile(
        length_m=length, v_start=vs, v_end=ve, v_cruise=vc, v_coast_end=v1,
        d_acc=d_acc, d_cruise=d_cruise, d_coast=d_coast, d_brake=d_brake,
        t_acc=(vc - vs) / a, t_cruise=d_cruise / vc if vc > 0 else 0.0,
        t_coast=(vc - v1) / c, t_brake=(v1 - ve) / b,
        energy_kwh=max(0.0, work) / dyn.efficiency / 3.6e6, dyn=dyn,
    )


def _vc_cap(length: float, vs: float, ve: float, dyn: TrainDynamics) -> float:
    """Максимальная скорость, достижимая при «разгон сразу в торможение» на длине length."""
    a, b = dyn.accel, dyn.brake
    v2 = (length + vs * vs / (2 * a) + ve * ve / (2 * b)) / (1 / (2 * a) + 1 / (2 * b))
    return math.sqrt(max(v2, 0.0))


def fastest(length: float, vs: float, ve: float, dyn: TrainDynamics, vlimit_kmh: float) -> SpeedProfile:
    """Профиль минимального времени хода (без выбега, на максимально допустимой скорости)."""
    length = max(length, 1.0)
    vmax = min(dyn.vmax_kmh, vlimit_kmh) * KMH
    vc = min(vmax, _vc_cap(length, vs, ve, dyn))
    vs, ve = min(vs, vc), min(ve, vc)
    vc = max(vc, vs, ve, 0.5)
    p = _build(length, vs, ve, vc, vc, dyn)
    if p is None:  # численная защита: очень короткий остаток
        p = _build(length, 0.0, 0.0, max(0.5, _vc_cap(length, 0, 0, dyn) * 0.99), max(0.5, _vc_cap(length, 0, 0, dyn) * 0.99), dyn)
    return p


def optimal(length: float, vs: float, ve: float, target_time: float, dyn: TrainDynamics,
            vlimit_kmh: float, step_kmh: float = 2.0) -> SpeedProfile:
    """Энергоэффективный профиль, прибывающий точно к target_time (если это возможно)."""
    length = max(length, 1.0)
    fast = fastest(length, vs, ve, dyn, vlimit_kmh)
    if target_time <= fast.total_time + 1.0:
        return fast
    vs, ve = fast.v_start, fast.v_end
    b, c = dyn.brake, dyn.coast
    v_hi = fast.v_cruise
    v_lo = min(v_hi, max(vs, ve, 15 * KMH))
    best: SpeedProfile | None = None
    slowest_early: SpeedProfile | None = None
    n = max(1, int((v_hi - v_lo) / (step_kmh * KMH)))
    for k in range(n + 1):
        vc = v_lo + (v_hi - v_lo) * k / n
        p_fast = _build(length, vs, ve, vc, vc, dyn)
        if p_fast is None or p_fast.total_time > target_time + 1.0:
            continue
        # максимальный выбег: участок хода с постоянной скоростью отсутствует
        rem = length - p_fast.d_acc
        denom = 1 / (2 * b) - 1 / (2 * c)
        v1sq = (rem - vc * vc / (2 * c) + ve * ve / (2 * b)) / denom
        v1_min = math.sqrt(min(vc * vc, max(ve * ve, v1sq)))
        p_slow = _build(length, vs, ve, vc, v1_min, dyn) or p_fast
        if p_slow.total_time < target_time - 1.0:
            if slowest_early is None or p_slow.total_time > slowest_early.total_time:
                slowest_early = p_slow
            continue
        lo, hi = v1_min, vc           # время хода убывает с ростом v1
        p = p_fast
        for _ in range(30):
            mid = (lo + hi) / 2
            cand = _build(length, vs, ve, vc, mid, dyn)
            if cand is None:
                lo = mid
                continue
            p = cand
            if cand.total_time > target_time:
                lo = mid
            else:
                hi = mid
        if best is None or p.energy_kwh < best.energy_kwh:
            best = p
    return best or slowest_early or fast


def recommendation(profile: SpeedProfile, fastest_profile: SpeedProfile) -> dict:
    saving = 0.0
    if fastest_profile.energy_kwh > 0:
        saving = 100 * (fastest_profile.energy_kwh - profile.energy_kwh) / fastest_profile.energy_kwh
    return {
        "cruise_kmh": round(profile.v_cruise / KMH, 1),
        "coast_from_m": round(profile.d_acc + profile.d_cruise),
        "brake_from_m": round(profile.d_acc + profile.d_cruise + profile.d_coast),
        "run_time_s": round(profile.total_time),
        "energy_kwh": round(profile.energy_kwh, 1),
        "energy_fastest_kwh": round(fastest_profile.energy_kwh, 1),
        "saving_pct": round(max(0.0, saving), 1),
        "phases": profile.phases(),
    }
