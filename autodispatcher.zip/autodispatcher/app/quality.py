"""Индекс качества движения (0–100, A–E) с прозрачной формулой и объяснимостью.

  Индекс = Σ wᵢ·Sᵢ / Σ wᵢ,  где Sᵢ ∈ [0, 100] — оценка фактора:

  S_расписание = 100 − k_зад · (средняя по приоритету прогнозная задержка на конечной, мин)
  S_прибытие   = 100 · (доля прибытий на остановки в пределах допуска ± tol мин)
  S_конфликты  = 100 − p_нер · (нерешённые) − p_обн · (обнаруженные в прогнозе)
  S_энергия    = 100 · E_норм / E_план  (дополнительные разгоны после внеплановых остановок)
  S_пропуск    = 100 · (поезда, проходящие участок за горизонт по плану / по нормативу)

Категории: ≥ norm — «Норма», ≥ attention — «Внимание», иначе «Критично».
Вклад фактора в потерю индекса: wᵢ·(100 − Sᵢ)/Σw — по нему строится top-5.
"""
from __future__ import annotations

from .ato import KMH
from .dispatcher import Plan

FACTOR_NAMES = {
    "schedule": "Соблюдение расписания",
    "arrival": "Точность прибытия и остановки",
    "conflicts": "Конфликты",
    "energy": "Энергоэффективность ведения",
    "capacity": "Использование пропускной способности",
}


def clamp(v: float, lo: float = 0.0, hi: float = 100.0) -> float:
    return max(lo, min(hi, v))


def category_of(value: float, thr: dict) -> tuple[str, str]:
    if value >= float(thr["norm"]):
        cat = ("norm", "Норма")
    elif value >= float(thr["attention"]):
        cat = ("attention", "Внимание")
    else:
        cat = ("critical", "Критично")
    return cat


def letter_of(value: float) -> str:
    return "A" if value >= 90 else "B" if value >= 80 else "C" if value >= 70 else "D" if value >= 60 else "E"


def compute(plan: Plan, specs: dict, cats: dict, now: float, horizon_s: float, qcfg: dict,
            detected: list, unresolved: list, topo_length_m: float) -> dict:
    w = {k: float(v) for k, v in qcfg["weights"].items()}
    p = qcfg["params"]
    tol = float(p["arrival_tolerance_min"]) * 60
    end = now + horizon_s

    # 1. Соблюдение расписания
    num = den = 0.0
    worst = (None, 0.0)
    for tid, tp in plan.trains.items():
        pr = cats[specs[tid].category].priority
        num += pr * tp.delay / 60
        den += pr
        if tp.delay > worst[1]:
            worst = (tid, tp.delay)
    avg_delay = num / den if den else 0.0
    s_sched = clamp(100 - float(p["delay_penalty_per_min"]) * avg_delay)
    d_sched = f"Средняя прогнозная задержка {avg_delay:.1f} мин"
    if worst[0] and worst[1] >= 60:
        d_sched += f"; наибольшая — {worst[0]} (+{worst[1] / 60:.0f} мин)"

    # 2. Точность прибытия
    total = ok = 0
    late_names = []
    for tid, tp in plan.trains.items():
        spec = specs[tid]
        for lg in tp.legs:
            if lg.st not in spec.stops or lg.arr is None or not (now <= lg.arr <= end):
                continue
            sched_arr = spec.sched.get(lg.st, (None, None))[0]
            if sched_arr is None:
                continue
            total += 1
            if abs(lg.arr - sched_arr) <= tol:
                ok += 1
            elif tid not in late_names:
                late_names.append(tid)
    s_arr = 100.0 * ok / total if total else 100.0
    d_arr = f"{ok} из {total} прибытий в допуске ±{tol / 60:.0f} мин" if total else "Нет прибытий в горизонте"
    if late_names:
        d_arr += " (вне допуска: " + ", ".join(late_names[:3]) + ("…" if len(late_names) > 3 else "") + ")"

    # 3. Конфликты
    s_conf = clamp(100 - float(p["unresolved_penalty"]) * len(unresolved) - float(p["detected_penalty"]) * len(detected))
    d_conf = f"Обнаружено в прогнозе: {len(detected)}, нерешённых в плане: {len(unresolved)}"

    # 4. Энергоэффективность
    e_nom = e_plan = 0.0
    extra_stops = 0
    for tid, tp in plan.trains.items():
        spec = specs[tid]
        c = cats[spec.category]
        m = c.dyn.mass_t * 1000
        ke = 0.5 * m * (0.8 * c.vmax_kmh * KMH) ** 2
        resist = m * c.dyn.coast * topo_length_m * len(tp.legs) / max(1, len(spec.path))
        n_sched = sum(1 for lg in tp.legs if lg.st in spec.stops and lg.st != spec.terminal)
        n_extra = sum(1 for lg in tp.legs if lg.stop and lg.st not in spec.stops)
        extra_stops += n_extra
        e_nom += resist + n_sched * ke
        e_plan += resist + (n_sched + n_extra) * ke
    s_energy = clamp(100 * e_nom / e_plan) if e_plan else 100.0
    d_energy = f"Внеплановых остановок с повторным разгоном: {extra_stops}"

    # 5. Пропускная способность
    nominal = planned = 0
    for tid, tp in plan.trains.items():
        spec = specs[tid]
        sa = spec.sched_arr_terminal()
        if sa is not None and now <= sa <= end:
            nominal += 1
            arr = tp.legs[-1].arr
            if arr is not None and arr <= end:
                planned += 1
    s_cap = 100.0 * planned / nominal if nominal else 100.0
    d_cap = f"Пройдут участок за горизонт: {planned} из {nominal} по нормативу" if nominal else "Нет поездов в горизонте"

    scores = {"schedule": (s_sched, d_sched), "arrival": (s_arr, d_arr), "conflicts": (s_conf, d_conf),
              "energy": (s_energy, d_energy), "capacity": (s_cap, d_cap)}
    wsum = sum(w.values()) or 1.0
    value = sum(w[k] * scores[k][0] for k in w) / wsum
    factors = []
    for k, (score, detail) in scores.items():
        wk = w.get(k, 0.0) / wsum
        factors.append({
            "key": k, "name": FACTOR_NAMES[k], "score": round(score, 1), "weight": round(wk, 3),
            "contribution": round(wk * score, 1), "loss": round(wk * (100 - score), 1), "detail": detail,
        })
    factors.sort(key=lambda f: -f["loss"])
    cat_key, cat_name = category_of(value, qcfg["thresholds"])
    return {
        "value": round(value, 1), "letter": letter_of(value), "category": cat_key, "category_name": cat_name,
        "factors": factors[:5], "avg_delay_min": round(avg_delay, 1),
        "total_delay_min": round(sum(tp.delay for tp in plan.trains.values()) / 60, 1),
    }
