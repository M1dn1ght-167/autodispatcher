"use strict";
/* Автодиспетчер — клиент дашборда. Без сборки и внешних библиотек: чистый JS + SVG. */

const $ = (id) => document.getElementById(id);
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const pad = (n) => String(n).padStart(2, "0");
const hhmm = (t) => { t = Math.floor(t) % 86400; if (t < 0) t += 86400; return pad(Math.floor(t / 3600)) + ":" + pad(Math.floor((t % 3600) / 60)); };
const hhmmss = (t) => hhmm(t) + ":" + pad(Math.floor(t) % 60);
const fmt = (v, d = 1) => (v == null ? "—" : Number(v).toLocaleString("ru-RU", { minimumFractionDigits: d, maximumFractionDigits: d }));
const CATS = { express: "Скоростной", passenger: "Пассажирский", freight: "Грузовой" };
const COLORS = { express: "#7A3FB0", passenger: "#0067A5", freight: "#7A5230" };
const STATUS = { running: "в пути", dwell: "на станции", pending: "готовится к отправлению", done: "прибыл" };
const LEVEL = { critical: "Критично", warning: "Внимание", info: "Информация" };
const SIG_COLORS = { green: "#1E8449", red: "#C0352B", fault: "#F2B705", closed: "#333" };

const S = {
  token: sessionStorage.getItem("ad_token"),
  user: JSON.parse(sessionStorage.getItem("ad_user") || "null"),
  topo: null, tick: null, plan: null, graph: null, accel: 1, strategies: [],
  selected: null, qhist: [], ws: null, retry: 0, lastMsg: 0, connected: false, reconnectAt: 0,
  replay: { on: false, frames: [], idx: 0, timer: null }, dirty: { graph: false, map: false },
};

// ---------- REST ----------
async function api(path, opts = {}) {
  const res = await fetch(path, {
    ...opts,
    headers: { "Content-Type": "application/json", ...(S.token ? { Authorization: "Bearer " + S.token } : {}) },
  });
  if (res.status === 401) { logout(); throw new Error("Сеанс истёк, войдите снова"); }
  if (!res.ok) {
    let msg = res.statusText;
    try { const j = await res.json(); msg = typeof j.detail === "string" ? j.detail : JSON.stringify(j.detail); } catch (_) { /* тело не JSON */ }
    throw new Error(msg);
  }
  return res.headers.get("content-type")?.includes("json") ? res.json() : res;
}

// ---------- вход ----------
function showLogin() { $("login").hidden = false; $("loginForm").password.focus(); }
function logout() {
  sessionStorage.removeItem("ad_token"); sessionStorage.removeItem("ad_user");
  S.token = null; S.user = null;
  if (S.ws) { S.ws.onclose = null; S.ws.close(); }
  showLogin();
}
$("loginForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const f = e.target;
  $("loginError").textContent = "";
  try {
    const r = await fetch("/api/auth/login", { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username: f.username.value, password: f.password.value }) });
    if (!r.ok) throw new Error("Неверное имя пользователя или пароль");
    const j = await r.json();
    S.token = j.token; S.user = { username: j.username, role: j.role };
    sessionStorage.setItem("ad_token", j.token); sessionStorage.setItem("ad_user", JSON.stringify(S.user));
    $("login").hidden = true;
    boot();
  } catch (err) { $("loginError").textContent = err.message; }
});
window.addEventListener("resize", () => { S.dirty.graph = S.dirty.map = true; });
$("btnLogout").addEventListener("click", logout);

// ---------- WebSocket: переподключение с экспоненциальной задержкой ----------
function connect() {
  const proto = location.protocol === "https:" ? "wss" : "ws";
  const ws = new WebSocket(`${proto}://${location.host}/ws?token=${encodeURIComponent(S.token)}`);
  S.ws = ws;
  ws.onopen = () => { S.connected = true; S.retry = 0; S.lastMsg = Date.now(); setConn(); };
  ws.onmessage = (ev) => { S.lastMsg = Date.now(); onMessage(JSON.parse(ev.data)); };
  ws.onclose = (ev) => {
    S.connected = false;
    if (ev.code === 4401) { logout(); return; }
    const delay = Math.min(30000, 1000 * 2 ** S.retry) * (0.8 + Math.random() * 0.4);
    S.retry += 1;
    S.reconnectAt = Date.now() + delay;
    setConn();
    setTimeout(() => { if (S.token) connect(); }, delay);
  };
  ws.onerror = () => ws.close();
}
function setConn() {
  const el = $("conn"), txt = el.querySelector("span");
  const age = (Date.now() - S.lastMsg) / 1000;
  el.className = "conn";
  if (S.connected && age < 3) { el.classList.add("ok"); txt.textContent = "Онлайн"; }
  else if (S.connected) { el.classList.add("retry"); txt.textContent = `Нет данных ${Math.round(age)} с`; }
  else if (age < 10 || !S.lastMsg) {
    el.classList.add("retry");
    txt.textContent = `Переподключение через ${Math.max(0, Math.ceil((S.reconnectAt - Date.now()) / 1000))} с`;
  } else { el.classList.add("lost"); txt.textContent = "Нет связи с сервером"; }
  document.body.classList.toggle("stale", !S.replay.on && S.lastMsg > 0 && age > 5);
}
setInterval(setConn, 1000);

function onMessage(m) {
  if (m.type === "hello") {
    S.topo = m.topology; S.accel = m.accel; S.strategies = m.strategies;
    $("sectionName").textContent = m.topology.name;
    $("accel").textContent = `ускорение ×${m.accel}`;
    fillSegments();
    return;
  }
  if (m.type === "tick") {
    S.tick = m;
    if (S.graph) appendTraces(m);
    if (!S.replay.on) { renderTickPanels(m); S.dirty.map = true; S.dirty.graph = true; }
    return;
  }
  if (m.type === "plan") {
    S.plan = m;
    if (m.quality) {
      const last = S.qhist[S.qhist.length - 1];
      if (!last || m.sim_t - last[0] > 20) S.qhist.push([m.sim_t, m.quality.value]);
      if (S.qhist.length > 600) S.qhist.shift();
    }
    if (!S.replay.on) renderPlanPanels(m);
    scheduleGraphFetch();
    if (m.reason && m.reason.includes("incident")) loadLog();
  }
}

// ---------- перерисовка с ограничением частоты ----------
function frame() {
  if (S.dirty.map) { S.dirty.map = false; renderMap(S.replay.on ? currentFrame() : S.tick); }
  if (S.dirty.graph) { S.dirty.graph = false; renderGraph(); }
  requestAnimationFrame(frame);
}

// ---------- панели онлайна ----------
function renderTickPanels(t) {
  $("clock").textContent = hhmmss(t.sim_t);
  renderIndexHead(t.index);
  renderIncidents(t.incidents);
  fillTrainSelects(t.trains);
  const f = t.feed;
  const p = S.plan || {};
  $("feedStats").textContent = `Поток данных: ${f.rate} сообщ./с, получено ${f.received}, дублей отброшено ${f.duplicates}, ` +
    `битых ${f.invalid}, не по порядку ${f.out_of_order}` +
    (p.compute_ms != null ? `. Пересчёт плана ${fmt(p.compute_ms, 0)} мс, обновление экрана ${fmt(p.latency_ms, 0)} мс` : "");
}

function renderIndexHead(idx) {
  if (!idx || idx.value == null) return;
  const cat = idx.category || "norm";
  $("indexValue").textContent = fmt(idx.value, 1);
  $("indexValue").className = "index-value cat-" + cat;
  $("indexLetter").textContent = idx.letter;
  $("indexLetter").className = "index-letter cat-" + cat;
  $("indexCat").textContent = { norm: "Норма", attention: "Внимание", critical: "Критично" }[cat];
  $("indexCat").className = "badge cat-" + cat;
}

function renderPlanPanels(p) {
  const q = p.quality;
  if (q) {
    renderIndexHead(q);
    $("factors").innerHTML = q.factors.map((f) => {
      const cls = f.score < 60 ? "low" : f.score < 80 ? "mid" : "hi";
      return `<li><span>${esc(f.name)}</span><span class="score">${fmt(f.score, 0)} · −${fmt(f.loss, 1)}</span>
        <span class="bar" role="img" aria-label="Оценка ${fmt(f.score, 0)} из 100"><b class="${cls}" style="width:${f.score}%"></b></span>
        <span class="detail">${esc(f.detail)} (вес ${Math.round(f.weight * 100)}%)</span></li>`;
    }).join("");
    renderSpark();
  }
  $("autoMode").checked = p.mode === "auto";
  $("planMeta").textContent = `Пересчитан в ${hhmm(p.sim_t)} за ${fmt(p.compute_ms, 0)} мс. ` +
    (p.mode === "auto" ? "Выбран вариант с лучшим индексом." : "Вариант зафиксирован диспетчером.");
  $("variants").innerHTML = p.variants.map((v) => `
    <div class="variant ${v.active ? "active" : ""}">
      <span class="name">${esc(v.label)}</span><span class="val cat-${v.category}">${fmt(v.index, 1)} ${v.letter}</span>
      <span class="hint">${esc(v.hint)}</span>
      <span class="stats">Суммарная задержка ${fmt(v.total_delay_min, 0)} мин${v.unresolved ? `, нерешённых конфликтов: ${v.unresolved}` : ", без конфликтов"}</span>
      ${v.active ? `<span class="tag">Действует сейчас</span>` : `<button class="btn small" data-apply="${v.strategy}">Применить</button>`}
    </div>`).join("");

  const alerts = p.alerts || [];
  $("alertCount").textContent = alerts.filter((a) => a.level === "critical").length || "";
  $("alerts").innerHTML = alerts.length ? alerts.map((a) => `<li class="${a.level}"><strong><span class="lvl">${LEVEL[a.level]}</span>${esc(a.title)}</strong><span>${esc(a.text)}</span></li>`).join("")
    : `<li class="empty">Всё спокойно: конфликтов и нештатных ситуаций нет.</li>`;
  const recs = p.recommendations || [];
  $("recs").innerHTML = recs.length ? recs.slice(0, 12).map((r) => `<li><span class="when">${r.until_hhmm}</span>
      <span>${esc(r.text)} на ${fmt(r.minutes, 0)} мин</span><span class="why">Причина: ${esc(r.reason)}. Отправить в ${r.until_hhmm}</span></li>`).join("")
    : `<li class="empty">Поезда идут без остановок на скрещениях.</li>`;
}

$("variants").addEventListener("click", async (e) => {
  const b = e.target.closest("[data-apply]");
  if (!b) return;
  b.disabled = true;
  try { await api("/api/plan/apply", { method: "POST", body: JSON.stringify({ strategy: b.dataset.apply }) }); }
  catch (err) { alert(err.message); }
});
$("autoMode").addEventListener("change", async (e) => {
  const strategy = e.target.checked ? "auto" : (S.plan?.strategy || "priority");
  try { await api("/api/plan/apply", { method: "POST", body: JSON.stringify({ strategy }) }); } catch (err) { alert(err.message); }
});

function renderSpark() {
  const pts = S.qhist.slice(-120);
  if (pts.length < 2) { $("spark").innerHTML = ""; return; }
  const t0 = pts[0][0], t1 = pts[pts.length - 1][0] || t0 + 1;
  const x = (t) => ((t - t0) / Math.max(1, t1 - t0)) * 300, y = (v) => 46 - ((Math.max(40, v) - 40) / 60) * 44;
  const line = pts.map((p) => `${x(p[0]).toFixed(1)},${y(p[1]).toFixed(1)}`).join(" ");
  $("spark").innerHTML = `
    <rect x="0" y="${y(100)}" width="300" height="${y(80) - y(100)}" fill="#E2F2E8"/>
    <rect x="0" y="${y(80)}" width="300" height="${y(60) - y(80)}" fill="#FBF0D6"/>
    <rect x="0" y="${y(60)}" width="300" height="${y(40) - y(60)}" fill="#F8E1DE"/>
    <polyline points="${line}" fill="none" stroke="#16283A" stroke-width="1.8" vector-effect="non-scaling-stroke"/>`;
}

// ---------- нештатные ситуации ----------
function fillSegments() {
  const st = S.topo.stations;
  $("incSeg").innerHTML = S.topo.segments.map((s) => `<option value="${s.id}">${esc(st[s.a].name)} — ${esc(st[s.b].name)}</option>`).join("");
}
function fillTrainSelects(trains) {
  const ids = trains.filter((t) => t.status !== "done").map((t) => t.id).sort();
  const key = ids.join(",");
  if (fillTrainSelects.key === key) return;
  fillTrainSelects.key = key;
  for (const sel of [$("incTrain"), $("atoTrain")]) {
    const cur = sel.value;
    sel.innerHTML = (sel.id === "atoTrain" ? `<option value="">Поезд…</option>` : "") +
      ids.map((id) => `<option value="${id}">${id}</option>`).join("");
    if (ids.includes(cur)) sel.value = cur;
  }
  if (S.selected) $("atoTrain").value = S.selected;
}
$("incType").addEventListener("change", (e) => {
  const delay = e.target.value === "delay";
  $("incTrainWrap").hidden = !delay; $("incSegWrap").hidden = delay;
});
$("incForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const f = e.target, body = { type: f.type.value, minutes: Number(f.minutes.value) };
  if (body.type === "delay") body.train_id = f.train_id.value; else body.segment_id = f.segment_id.value;
  const t0 = performance.now();
  try {
    const inc = await api("/api/incidents", { method: "POST", body: JSON.stringify(body) });
    $("incMsg").textContent = `Внесено: ${inc.text}. План пересчитывается…`;
    waitPlan(t0);
  } catch (err) { $("incMsg").textContent = err.message; }
});
$("btnStorm").addEventListener("click", async () => {
  const t0 = performance.now();
  try {
    const list = await api("/api/incidents/storm", { method: "POST", body: JSON.stringify({ count: 10 }) });
    $("incMsg").textContent = `Внесено одновременно: ${list.length} ситуаций. План пересчитывается…`;
    waitPlan(t0);
  } catch (err) { $("incMsg").textContent = err.message; }
});
function waitPlan(t0) {
  const prev = S.plan?.sim_t;
  const check = () => {
    if (S.plan && S.plan.sim_t !== prev) {
      $("incMsg").textContent += ` Готово: новый план через ${Math.round(performance.now() - t0)} мс, индекс ${fmt(S.plan.quality.value, 1)}.`;
    } else if (performance.now() - t0 < 10000) setTimeout(check, 50);
  };
  check();
}
function renderIncidents(list) {
  $("incidents").innerHTML = (list || []).map((i) => `<li class="${i.type}"><span>${esc(i.text)}</span>
    <button class="btn small" data-resolve="${i.id}">Снять</button></li>`).join("");
}
$("incidents").addEventListener("click", async (e) => {
  const b = e.target.closest("[data-resolve]");
  if (!b) return;
  b.disabled = true;
  try { await api("/api/incidents/" + b.dataset.resolve, { method: "DELETE" }); } catch (err) { alert(err.message); }
});

// ---------- поездограмма ----------
let graphTimer = null;
function scheduleGraphFetch() {
  clearTimeout(graphTimer);
  graphTimer = setTimeout(loadGraph, 150);
}
async function loadGraph() {
  try { S.graph = await api("/api/graph?before_min=90&after_min=150"); S.dirty.graph = true; } catch (_) { /* повторим позже */ }
}
setInterval(() => { if (S.token && !S.replay.on) loadGraph(); }, 15000);

function appendTraces(t) {
  const g = S.graph;
  for (const tr of t.trains) {
    if (tr.status !== "running" && tr.status !== "dwell") continue;
    const arr = g.traces[tr.id] || (g.traces[tr.id] = []);
    const last = arr[arr.length - 1];
    if (!last || t.sim_t - last[0] >= 8) arr.push([t.sim_t, tr.km]);
    g.categories[tr.id] = g.categories[tr.id] || tr.cat;
  }
}

function renderGraph() {
  const g = S.graph, topo = S.topo;
  if (!g || !topo) return;
  const now = S.replay.on ? currentFrame().sim_t : (S.tick?.sim_t ?? g.now);
  const t0 = now - 90 * 60, t1 = now + 150 * 60;
  const svg = $("graph");
  const W = Math.max(760, svg.clientWidth || 1200), H = svg.clientHeight || 470, L = 120, R = 12, T = 28, B = 14;
  svg.setAttribute("viewBox", `0 0 ${W} ${H}`);
  const len = topo.length_km;
  const x = (t) => L + ((t - t0) / (t1 - t0)) * (W - L - R);
  const y = (km) => T + (km / len) * (H - T - B);
  const out = [`<defs>
    <pattern id="hatchRed" width="8" height="8" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><rect width="8" height="8" fill="rgba(192,53,43,.08)"/><line x1="0" y1="0" x2="0" y2="8" stroke="#C0352B" stroke-width="2"/></pattern>
    <pattern id="hatchAmber" width="8" height="8" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><rect width="8" height="8" fill="rgba(242,183,5,.08)"/><line x1="0" y1="0" x2="0" y2="8" stroke="#D9A400" stroke-width="2"/></pattern>
    <clipPath id="plot"><rect x="${L}" y="${T - 4}" width="${W - L - R}" height="${H - T - B + 8}"/></clipPath></defs>`];
  // сетка: каждые 10 минут, часы жирнее
  for (let t = Math.ceil(t0 / 600) * 600; t <= t1; t += 600) {
    const hour = t % 3600 === 0;
    out.push(`<line class="g-grid ${hour ? "hour" : ""}" x1="${x(t)}" y1="${T}" x2="${x(t)}" y2="${H - B}"/>`);
    if (t % 1800 === 0) out.push(`<text class="g-time" x="${x(t)}" y="${T - 10}" text-anchor="middle">${hhmm(t)}</text>`);
  }
  for (const st of topo.stations) {
    const isSt = st.kind === "station";
    out.push(`<line class="g-st ${isSt ? "station" : ""}" x1="${L}" y1="${y(st.km)}" x2="${W - R}" y2="${y(st.km)}"/>`);
    out.push(`<text class="g-label ${isSt ? "" : "siding"}" x="${L - 8}" y="${y(st.km) + 4}" text-anchor="end">${esc(st.name)}</text>`);
  }
  out.push(`<g clip-path="url(#plot)">`);
  for (const c of g.closures) {
    if (S.replay.on && c.start > now) continue;
    const xa = x(Math.max(c.start, t0)), xb = x(Math.min(c.end, t1));
    if (xb <= xa) continue;
    out.push(`<rect class="${c.type === "closure" ? "g-closure" : "g-fault"}" x="${xa}" y="${y(c.from_km)}" width="${xb - xa}" height="${y(c.to_km) - y(c.from_km)}"><title>${c.type === "closure" ? "Закрытие перегона" : "Неисправность сигнала, ограничение скорости"}</title></rect>`);
  }
  const sel = S.selected;
  const cls = (id) => (sel ? (id === sel ? "sel" : "dim") : "");
  const poly = (pts) => pts.map((p) => `${x(p[0]).toFixed(1)},${y(p[1]).toFixed(1)}`).join(" ");
  for (const [id, pts] of Object.entries(g.nominal)) {
    out.push(`<polyline class="g-nominal ${sel && id !== sel ? "dim" : ""}" stroke="${COLORS[g.categories[id]] || "#555"}" points="${poly(pts)}"/>`);
  }
  if (!S.replay.on) {
    for (const [id, pts] of Object.entries(g.plan)) {
      const live = S.tick?.trains.find((t) => t.id === id);
      const p2 = live && live.status === "running" ? [[now, live.km], ...pts.filter((p) => p[0] > now)] : pts;
      out.push(`<polyline class="g-plan ${cls(id)}" stroke="${COLORS[g.categories[id]] || "#555"}" points="${poly(p2)}"/>`);
    }
  }
  for (const [id, pts0] of Object.entries(g.traces)) {
    const pts = pts0.filter((p) => p[0] <= now && p[0] >= t0 - 600);
    if (pts.length < 1) continue;
    const color = COLORS[g.categories[id]] || "#555";
    out.push(`<polyline class="g-actual ${cls(id)}" stroke="${color}" points="${poly(pts)}" data-train="${id}"><title>${id}</title></polyline>`);
    const lp = pts[pts.length - 1];
    if (now - lp[0] < 120) {
      out.push(`<text class="g-train-label ${sel && id !== sel ? "dim" : ""}" data-train="${id}" x="${x(lp[0]) + 5}" y="${y(lp[1]) - 5}" fill="${color}">${id}</text>`);
    }
  }
  if (!S.replay.on) {
    for (const c of g.conflicts || []) {
      if (c.at < t0 || c.at > t1) continue;
      out.push(`<circle class="g-conflict" cx="${x(c.at)}" cy="${y(c.km)}" r="8"><title>${esc(c.title)}: ${esc(c.trains.join(" / "))}, ${esc(c.where)}, ${c.time}. ${esc(c.resolution)}</title></circle>`);
    }
  }
  out.push(`</g>`);
  out.push(`<line class="g-now" x1="${x(now)}" y1="${T - 2}" x2="${x(now)}" y2="${H - B}"/>`);
  out.push(`<rect x="${x(now) - 24}" y="2" width="48" height="16" rx="3" fill="${S.replay.on ? "#B97800" : "#16283A"}"/>
    <text class="g-now-label" x="${x(now)}" y="14" text-anchor="middle">${hhmm(now)}</text>`);
  svg.innerHTML = out.join("");
}
$("graph").addEventListener("pointerdown", (e) => {
  const id = e.target.closest("[data-train]")?.dataset.train;
  selectTrain(id && id !== S.selected ? id : null);
});

// ---------- схема участка ----------
function renderMap(t) {
  const topo = S.topo;
  if (!t || !topo) return;
  const svg = $("map");
  const W = Math.max(760, svg.clientWidth || 1200), H = 170, L = 60, R = 60, Y = 82;
  svg.setAttribute("viewBox", `0 0 ${W} ${H}`);
  const x = (km) => L + (km / topo.length_km) * (W - L - R);
  const out = [`<line class="m-track" x1="${x(0) - 30}" y1="${Y}" x2="${x(topo.length_km) + 30}" y2="${Y}"/>`];
  for (const inc of t.incidents || []) {
    if (inc.segment_idx == null) continue;
    const s = topo.segments[inc.segment_idx];
    out.push(`<line class="${inc.type === "closure" ? "m-closed" : "m-fault"}" x1="${x(topo.stations[s.a].km) + 22}" y1="${Y}" x2="${x(topo.stations[s.b].km) - 22}" y2="${Y}"><title>${esc(inc.text)}</title></line>`);
  }
  for (const st of topo.stations) {
    const cx = x(st.km), isSt = st.kind === "station";
    const n = Math.min(st.tracks - 1, 2);
    for (let k = 1; k <= n; k++) {
      const yy = Y - 13 * k, w = isSt ? 30 : 24;
      out.push(`<path class="m-siding" d="M${cx - w - 10},${Y} L${cx - w},${yy} L${cx + w},${yy} L${cx + w + 10},${Y}"/>`);
    }
    out.push(`<text class="m-st-name ${isSt ? "" : "siding"}" x="${cx}" y="${Y + 40}">${esc(st.name)}</text>`);
    out.push(`<text class="m-km" x="${cx}" y="${Y + 54}">${st.km} км</text>`);
    const sOdd = t.signals[`${st.id}:odd`], sEven = t.signals[`${st.id}:even`];
    if (sOdd) out.push(signal(cx + 26, Y + 14, sOdd, `Выходной сигнал ${st.name}, нечётное направление`));
    if (sEven) out.push(signal(cx - 26, Y + 14, sEven, `Выходной сигнал ${st.name}, чётное направление`));
  }
  const atStation = {};
  for (const tr of t.trains) {
    if (tr.status === "done") continue;
    let ty = Y, tx = x(tr.km);
    if (tr.status !== "running") {
      const k = (atStation[tr.st] = (atStation[tr.st] || 0) + 1) - 1;
      ty = Y - 13 * k;
    }
    const color = COLORS[tr.cat] || "#555";
    const w = 52, h = 16, dir = tr.dir;
    const nose = dir > 0 ? `${tx + w / 2},${ty - h / 2} ${tx + w / 2 + 7},${ty} ${tx + w / 2},${ty + h / 2}` : `${tx - w / 2},${ty - h / 2} ${tx - w / 2 - 7},${ty} ${tx - w / 2},${ty + h / 2}`;
    const above = tr.status === "running" ? ty + h / 2 + 11 : ty - h / 2 - 4;
    const delay = tr.delay >= 1 || tr.hold ? `<text class="delay" x="${tx}" y="${above}">${tr.hold ? "стоит " : ""}${tr.delay >= 1 ? "+" + Math.round(tr.delay) : ""}</text>` : "";
    const hold = "";
    const label = `${tr.id}, ${CATS[tr.cat] || ""}, ${STATUS[tr.status]}, ${fmt(tr.v, 0)} км/ч${tr.delay >= 1 ? `, опоздание ${Math.round(tr.delay)} мин` : ""}`;
    out.push(`<g class="m-train ${S.selected === tr.id ? "selected" : ""}" data-train="${tr.id}" tabindex="0" role="button" aria-label="${esc(label)}">
      <title>${esc(label)}</title>
      <polygon points="${nose}" fill="${color}"/><rect x="${tx - w / 2}" y="${ty - h / 2}" width="${w}" height="${h}" rx="3" fill="${color}"/>
      <text x="${tx}" y="${ty + 4}">${tr.id}</text>${delay}${hold}</g>`);
  }
  const focused = document.activeElement?.closest?.("#map [data-train]")?.dataset.train;
  svg.innerHTML = out.join("");
  if (focused) svg.querySelector(`[data-train="${CSS.escape(focused)}"]`)?.focus();
}
function signal(cx, cy, state, title) {
  return `<g><title>${esc(title)}: ${({ green: "свободно", red: "занято", fault: "неисправность", closed: "перегон закрыт" })[state]}</title>
    <line x1="${cx}" y1="${cy - 6}" x2="${cx}" y2="${cy + 8}" stroke="#4A5D6E" stroke-width="1.5"/>
    <circle cx="${cx}" cy="${cy - 6}" r="5" fill="${SIG_COLORS[state]}" stroke="#16283A" stroke-width="1"/></g>`;
}
$("map").addEventListener("pointerdown", (e) => {
  const id = e.target.closest("[data-train]")?.dataset.train;
  if (id) selectTrain(id === S.selected ? null : id);
});
$("map").addEventListener("keydown", (e) => {
  if (e.key !== "Enter" && e.key !== " ") return;
  const id = e.target.closest("[data-train]")?.dataset.train;
  if (id) { e.preventDefault(); selectTrain(id); }
});

// ---------- автоведение ----------
function selectTrain(id) {
  S.selected = id || null;
  $("atoTrain").value = id || "";
  S.dirty.map = S.dirty.graph = true;
  loadAto();
}
$("atoTrain").addEventListener("change", (e) => selectTrain(e.target.value));
async function loadAto() {
  if (!S.selected) { $("atoInfo").textContent = "Выберите поезд на схеме или в списке."; $("atoChart").innerHTML = ""; return; }
  try { renderAto(await api("/api/ato/" + encodeURIComponent(S.selected))); }
  catch (_) { $("atoInfo").textContent = `${S.selected}: поезд покинул участок.`; $("atoChart").innerHTML = ""; }
}
setInterval(() => { if (S.selected && !S.replay.on) loadAto(); }, 2000);

function renderAto(a) {
  const c = a.current;
  const hintCls = c && /^(Снизить|Увеличить)/.test(c.hint) ? "adjust" : "";
  $("atoInfo").innerHTML = `
    <div>${esc(a.train_id)}, ${esc(CATS[a.category])}<b>${esc(a.from)} → ${esc(a.to)}</b></div>
    <div>Рекомендуемая скорость<b>${fmt(a.cruise_kmh, 0)} км/ч</b></div>
    <div>Выбег с<b>${fmt(a.coast_from_km, 1)} км</b></div>
    <div>Прибытие по профилю<b>${a.arrival}${a.planned_arrival ? ` (план ${a.planned_arrival})` : ""}</b></div>
    <div>Энергия на тягу<b>${fmt(a.energy_kwh, 0)} кВт·ч</b></div>
    <div>Экономия к «максимальному ходу»<b>${fmt(a.saving_pct, 0)}%</b></div>
    ${c ? `<div class="hint ${hintCls}">Сейчас ${fmt(c.speed_kmh, 0)} км/ч, рекомендуется ${fmt(c.recommended_kmh, 0)} км/ч. ${esc(c.hint)}.</div>` :
      `<div class="hint">Поезд ${STATUS[a.status]}. Профиль рассчитан на следующий перегон.</div>`}`;
  const W = 640, H = 220, L = 42, R = 10, T = 14, B = 30;
  const span = Math.abs(a.to_km - a.from_km) || 1;
  const vmax = Math.max(a.vlimit_kmh, ...a.fastest.map((p) => p[1])) + 10;
  const x = (km) => L + (Math.abs(km - a.from_km) / span) * (W - L - R);
  const y = (v) => H - B - (v / vmax) * (H - T - B);
  const line = (pts) => pts.map((p) => `${x(p[0]).toFixed(1)},${y(p[1]).toFixed(1)}`).join(" ");
  const out = [];
  for (let v = 0; v <= vmax; v += 20) {
    out.push(`<line class="a-axis" x1="${L}" y1="${y(v)}" x2="${W - R}" y2="${y(v)}" opacity=".5"/><text class="a-txt" x="${L - 6}" y="${y(v) + 4}" text-anchor="end">${v}</text>`);
  }
  out.push(`<text class="a-txt" x="${L}" y="${H - 8}">${fmt(a.from_km, 0)} км, ${esc(a.from)}</text><text class="a-txt" x="${W - R}" y="${H - 8}" text-anchor="end">${esc(a.to)}, ${fmt(a.to_km, 0)} км</text>`);
  out.push(`<text class="a-txt" x="${L + 4}" y="${T + 2}">км/ч</text>`);
  out.push(`<line class="a-limit" x1="${L}" y1="${y(a.vlimit_kmh)}" x2="${W - R}" y2="${y(a.vlimit_kmh)}"/><text class="a-txt" x="${W - R}" y="${y(a.vlimit_kmh) - 4}" text-anchor="end" fill="#C0352B">ограничение ${a.vlimit_kmh} км/ч</text>`);
  out.push(`<polygon class="a-area" points="${x(a.from_km)},${y(0)} ${line(a.profile)} ${x(a.to_km)},${y(0)}"/>`);
  out.push(`<polyline class="a-fast" points="${line(a.fastest)}"><title>Максимальный ход</title></polyline>`);
  out.push(`<polyline class="a-line" points="${line(a.profile)}"><title>Рекомендуемый профиль</title></polyline>`);
  for (const [km, txt] of [[a.coast_from_km, "выбег"], [a.brake_from_km, "торможение"]]) {
    out.push(`<line class="a-mark" x1="${x(km)}" y1="${T}" x2="${x(km)}" y2="${H - B}"/><text class="a-txt" x="${x(km) + 3}" y="${T + 14}">${txt}</text>`);
  }
  if (c) out.push(`<circle class="a-cur" cx="${x(c.km)}" cy="${y(c.speed_kmh)}" r="6"><title>Факт: ${fmt(c.speed_kmh, 0)} км/ч</title></circle>`);
  $("atoChart").innerHTML = out.join("");
}

// ---------- журнал ----------
async function loadLog() {
  try {
    const ev = await api("/api/history/events?minutes=60");
    $("log").innerHTML = ev.length ? ev.slice(0, 80).map((e) => `<li class="${e.level}"><time>${hhmm(e.sim_t)}</time><span>${esc(e.message)}</span></li>`).join("")
      : `<li class="empty">Событий пока нет.</li>`;
  } catch (_) { /* повторим позже */ }
}
setInterval(() => { if (S.token) loadLog(); }, 10000);

// ---------- перемотка ----------
const currentFrame = () => S.replay.frames[S.replay.idx];
$("btnReplay").addEventListener("click", async () => {
  try {
    const frames = await api("/api/history/snapshots?minutes=15&step=2");
    if (frames.length < 2) { alert("История пока короткая: подождите минуту после запуска."); return; }
    S.replay = { on: true, frames, idx: 0, timer: null };
    $("rpSlider").max = frames.length - 1; $("rpSlider").value = 0;
    $("replayBar").hidden = false; document.body.classList.add("replaying");
    playReplay(true);
    showFrame();
  } catch (err) { alert(err.message); }
});
function showFrame() {
  const f = currentFrame();
  $("rpTime").textContent = hhmmss(f.sim_t);
  $("clock").textContent = hhmmss(f.sim_t);
  renderIndexHead(f.index);
  renderIncidents(f.incidents);
  S.dirty.map = S.dirty.graph = true;
}
function playReplay(on) {
  clearInterval(S.replay.timer);
  $("rpPlay").textContent = on ? "Пауза" : "Воспроизвести";
  if (!on) return;
  S.replay.timer = setInterval(() => {
    if (S.replay.idx >= S.replay.frames.length - 1) { playReplay(false); return; }
    S.replay.idx += 1; $("rpSlider").value = S.replay.idx; showFrame();
  }, 100);
}
$("rpPlay").addEventListener("click", () => playReplay($("rpPlay").textContent !== "Пауза"));
$("rpSlider").addEventListener("input", (e) => { S.replay.idx = Number(e.target.value); playReplay(false); showFrame(); });
$("rpExit").addEventListener("click", () => {
  playReplay(false);
  S.replay.on = false;
  $("replayBar").hidden = true; document.body.classList.remove("replaying");
  if (S.plan) renderPlanPanels(S.plan);
  if (S.tick) renderTickPanels(S.tick);
  S.dirty.map = S.dirty.graph = true;
  loadGraph();
});

// ---------- отчёты ----------
$("btnCsv").addEventListener("click", async () => {
  try {
    const res = await api("/api/report.csv?minutes=15");
    const url = URL.createObjectURL(await res.blob());
    const a = Object.assign(document.createElement("a"), { href: url, download: "autodispatcher_report.csv" });
    document.body.append(a); a.click(); a.remove(); URL.revokeObjectURL(url);
  } catch (err) { alert(err.message); }
});
$("btnPdf").addEventListener("click", async () => {
  const w = window.open("", "_blank");
  if (!w) { alert("Разрешите всплывающие окна для печати отчёта."); return; }
  w.document.write("<p style='font-family:sans-serif'>Формирую отчёт…</p>");
  try {
    const r = await api("/api/report?minutes=15");
    const q = r.quality || {};
    const rows = (arr, f) => arr.map(f).join("");
    w.document.open();
    w.document.write(`<!doctype html><html lang="ru"><head><meta charset="utf-8"><title>Отчёт Автодиспетчера ${r.generated_sim}</title>
      <style>body{font:13px/1.45 "IBM Plex Sans",Arial,sans-serif;color:#16283A;margin:28px}h1{font-size:22px;margin:0}h2{font-size:15px;margin:20px 0 6px}
      table{border-collapse:collapse;width:100%}td,th{border:1px solid #D5DEDA;padding:4px 8px;text-align:left;vertical-align:top}th{background:#EEF3F0}
      .big{font-size:40px;font-weight:600}.note{color:#4A5D6E;font-size:11px;margin-top:24px}</style></head><body>
      <h1>Мини-отчёт: ${esc(r.section)}</h1>
      <p>Модельное время ${r.generated_sim}, сформирован ${esc(r.generated_real)}, период — последние ${r.minutes} мин. Действующий вариант плана: ${esc(r.strategy || "—")}.</p>
      <p><span class="big">${fmt(q.value, 1)}</span> индекс качества, класс ${q.letter}, «${esc(q.category_name)}»</p>
      <h2>Факторы индекса</h2><table><tr><th>Фактор</th><th>Оценка</th><th>Вес</th><th>Потеря индекса</th><th>Пояснение</th></tr>
      ${rows(q.factors || [], (f) => `<tr><td>${esc(f.name)}</td><td>${fmt(f.score, 0)}</td><td>${Math.round(f.weight * 100)}%</td><td>${fmt(f.loss, 1)}</td><td>${esc(f.detail)}</td></tr>`)}</table>
      <h2>Нештатные ситуации</h2><table><tr><th>Тип</th><th>Описание</th><th>Состояние</th></tr>
      ${rows(r.incidents, (i) => `<tr><td>${esc(i.label)}</td><td>${esc(i.text)}</td><td>${i.active ? "действует" : "снята"}</td></tr>`) || "<tr><td colspan=3>Не было</td></tr>"}</table>
      <h2>Рекомендации диспетчеру</h2><table><tr><th>Время</th><th>Рекомендация</th><th>Причина</th></tr>
      ${rows(r.recommendations, (x) => `<tr><td>${x.until_hhmm}</td><td>${esc(x.text)} на ${fmt(x.minutes, 0)} мин</td><td>${esc(x.reason)}</td></tr>`) || "<tr><td colspan=3>Нет</td></tr>"}</table>
      <h2>Прогнозные опоздания</h2><table><tr><th>Поезд</th><th>Задержка на конечной, мин</th></tr>
      ${rows(r.trains.filter((t) => t.delay_min > 0).slice(0, 15), (t) => `<tr><td>${t.id}</td><td>${fmt(t.delay_min, 1)}</td></tr>`) || "<tr><td colspan=2>Все по графику</td></tr>"}</table>
      <h2>Журнал событий</h2><table><tr><th>Время</th><th>Событие</th></tr>
      ${rows(r.events.slice(0, 40), (e) => `<tr><td>${hhmm(e.sim_t)}</td><td>${esc(e.message)}</td></tr>`)}</table>
      <h2>Показатели сервиса</h2><p>Пересчёт плана: медиана ${r.metrics.replan_ms_p50} мс, 95% — ${r.metrics.replan_ms_p95} мс.
      Обновление экрана после события: медиана ${r.metrics.update_latency_ms_p50} мс, 95% — ${r.metrics.update_latency_ms_p95} мс.</p>
      <p class="note">Демонстрационный прототип системы поддержки решений. Рекомендации не являются командами управления движением и не заменяют СЦБ, АЛСН/АЛС-ЕН и другие сертифицированные системы безопасности. Данные вымышленные.</p>
      <script>setTimeout(()=>print(),300)<\/script></body></html>`);
    w.document.close();
  } catch (err) { w.document.body.textContent = err.message; }
});

// ---------- настройки (admin) ----------
const W_NAMES = { schedule: "Соблюдение расписания", arrival: "Точность прибытия", conflicts: "Конфликты", energy: "Энергоэффективность", capacity: "Пропускная способность" };
$("btnSettings").addEventListener("click", async () => {
  try {
    const c = await api("/api/config");
    S.cfg = c;
    $("setWeights").innerHTML = Object.entries(c.quality.weights).map(([k, v]) => `<label>${W_NAMES[k] || k}<input type="number" step="0.05" min="0" name="w_${k}" value="${v}"></label>`).join("");
    $("setPrio").innerHTML = Object.entries(c.categories).map(([k, v]) => `<label>${esc(v.name)}<input type="number" step="1" min="0" max="10" name="pr_${k}" value="${v.priority}"></label>`).join("");
    const f = $("settingsForm");
    f.thr_norm.value = c.quality.thresholds.norm; f.thr_attention.value = c.quality.thresholds.attention;
    f.p_delay.value = c.quality.params.delay_penalty_per_min; f.p_tol.value = c.quality.params.arrival_tolerance_min;
    f.d_headway.value = c.dispatcher.headway_min; f.d_gap.value = c.dispatcher.crossing_gap_s;
    $("setMsg").textContent = "";
    $("settings").showModal();
  } catch (err) { alert(err.message); }
});
$("setSave").addEventListener("click", async (e) => {
  e.preventDefault();
  const f = $("settingsForm"), c = S.cfg;
  const weights = {}; for (const k of Object.keys(c.quality.weights)) weights[k] = Number(f["w_" + k].value);
  const categories = {}; for (const k of Object.keys(c.categories)) categories[k] = { priority: Number(f["pr_" + k].value) };
  const body = {
    quality: { weights, thresholds: { norm: Number(f.thr_norm.value), attention: Number(f.thr_attention.value) },
      params: { ...c.quality.params, delay_penalty_per_min: Number(f.p_delay.value), arrival_tolerance_min: Number(f.p_tol.value) } },
    dispatcher: { headway_min: Number(f.d_headway.value), crossing_gap_s: Number(f.d_gap.value) },
    categories,
  };
  try { await api("/api/config", { method: "PUT", body: JSON.stringify(body) }); $("settings").close(); }
  catch (err) { $("setMsg").textContent = err.message; }
});

// ---------- запуск ----------
async function boot() {
  $("btnLogout").textContent = `Выйти (${S.user?.username || ""})`;
  $("btnSettings").hidden = S.user?.role !== "admin";
  try {
    const qh = await api("/api/history/quality?minutes=60");
    S.qhist = qh.map((q) => [q.sim_t, q.value]);
  } catch (_) { /* история пуста */ }
  connect();
  loadGraph();
  loadLog();
}
requestAnimationFrame(frame);
if (S.token) boot(); else showLogin();
