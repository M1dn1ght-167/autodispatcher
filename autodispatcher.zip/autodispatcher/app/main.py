"""HTTP/WebSocket API «Автодиспетчера». Документация: /docs (Swagger UI), /openapi.json."""
from __future__ import annotations

import csv
import io
import json
import logging
import time
from contextlib import asynccontextmanager
from typing import Literal

from fastapi import Depends, FastAPI, HTTPException, Query, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, PlainTextResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from . import auth, settings
from .config import ConfigStore
from .engine import Engine, hhmm
from .storage import Storage
from .topology import Topology

logging.basicConfig(level=settings.LOG_LEVEL,
                    format='{"t":"%(asctime)s","lvl":"%(levelname)s","mod":"%(name)s","msg":"%(message)s"}')
log = logging.getLogger("api")

engine: Engine | None = None


@asynccontextmanager
async def lifespan(_: FastAPI):
    global engine
    engine = Engine(ConfigStore(settings.CONFIG_PATH), Topology.load(settings.TOPOLOGY_PATH), Storage(settings.DB_PATH))
    await engine.start()
    log.info("Автодиспетчер запущен")
    yield
    await engine.stop()


DESCRIPTION = """
**Демонстрационный прототип системы поддержки решений диспетчера.**

Все решения автодиспетчеризации и автоведения — **рекомендации** диспетчеру и машинисту,
а не команды, управляющие движением реального поезда. Система **не заменяет**
сертифицированные системы обеспечения безопасности движения (СЦБ, АЛСН/АЛС-ЕН и др.).

Аутентификация: `POST /api/auth/login` → токен; далее заголовок `Authorization: Bearer <токен>`.
Онлайн-данные: WebSocket `/ws?token=<токен>` (сообщения `tick` 2 Гц и `plan` при каждом пересчёте).
Внешний поток телеметрии: WebSocket `/ws/ingest?token=<токен>`.
"""

app = FastAPI(title="Автодиспетчер API", version="1.0.0", description=DESCRIPTION, lifespan=lifespan)


def eng() -> Engine:
    if engine is None:
        raise HTTPException(503, "Сервис запускается")
    return engine


# ---------- модели запросов ----------
class LoginIn(BaseModel):
    username: str
    password: str


class IncidentIn(BaseModel):
    type: Literal["delay", "signal_fault", "closure"] = Field(description="Тип нештатной ситуации")
    minutes: float = Field(10, ge=1, le=240)
    train_id: str | None = Field(None, description="Для type=delay")
    segment_id: str | None = Field(None, description="Для signal_fault и closure, напр. KOK-AKB")


class StormIn(BaseModel):
    count: int = Field(10, ge=1, le=20)


class ApplyIn(BaseModel):
    strategy: str = Field(description="auto | priority | punctual | fifo | hold_freight")


# ---------- служебное ----------
@app.get("/api/health", tags=["Сервис"])
def health():
    e = engine
    if e is None:
        return {"status": "starting"}
    age = time.monotonic() - e.last_feed_real
    return {"status": "ok" if age < 5 else "degraded", "feed_age_s": round(age, 1), "sim_time": hhmm(e.sim_now()),
            "trains_on_section": sum(1 for r in e.state.trains.values() if r["status"] != "done"),
            "ws_clients": len(e.clients), "config_version": e.cfg_store.version}


@app.get("/metrics", tags=["Сервис"], response_class=PlainTextResponse)
def metrics():
    e = eng()
    e.metrics.set("trains_on_section", sum(1 for r in e.state.trains.values() if r["status"] != "done"))
    e.metrics.set("bus_dropped", e.bus.dropped)
    return e.metrics.prometheus()


@app.post("/api/auth/login", tags=["Аутентификация"])
def login(body: LoginIn):
    res = auth.login(body.username, body.password)
    if not res:
        raise HTTPException(401, "Неверное имя пользователя или пароль")
    return res


# ---------- данные ----------
@app.get("/api/topology", tags=["Данные"])
def topology(_: dict = Depends(auth.current_user)):
    return eng().topo.to_dict()


@app.get("/api/state", tags=["Данные"])
def state(_: dict = Depends(auth.current_user)):
    e = eng()
    return e.tick_payload(e.sim_now())


@app.get("/api/plan", tags=["Автодиспетчер"])
def plan(_: dict = Depends(auth.current_user)):
    return eng().result


@app.get("/api/graph", tags=["Автодиспетчер"], summary="Данные поездограммы")
def graph(before_min: float = Query(90, ge=10, le=300), after_min: float = Query(150, ge=10, le=300),
          _: dict = Depends(auth.current_user)):
    return eng().graph(before_min, after_min)


@app.post("/api/plan/apply", tags=["Автодиспетчер"], summary="Применить вариант плана")
def apply_variant(body: ApplyIn, _: dict = Depends(auth.current_user)):
    try:
        eng().set_mode(body.strategy)
    except ValueError as ex:
        raise HTTPException(400, str(ex)) from ex
    return {"mode": body.strategy}


@app.get("/api/ato/{train_id}", tags=["Автоведение"], summary="Рекомендуемый профиль скорости")
def ato_profile(train_id: str, _: dict = Depends(auth.current_user)):
    try:
        return eng().ato_advice(train_id)
    except KeyError as ex:
        raise HTTPException(404, "Поезд не найден на участке") from ex


# ---------- нештатные ситуации ----------
@app.get("/api/incidents", tags=["Нештатные ситуации"])
def incidents(_: dict = Depends(auth.current_user)):
    return sorted(eng().incidents.values(), key=lambda i: -i["start"])


@app.post("/api/incidents", tags=["Нештатные ситуации"], status_code=201)
def add_incident(body: IncidentIn, _: dict = Depends(auth.current_user)):
    try:
        return eng().add_incident(body.type, body.minutes, body.train_id, body.segment_id)
    except ValueError as ex:
        raise HTTPException(400, str(ex)) from ex


@app.post("/api/incidents/storm", tags=["Нештатные ситуации"], summary="Всплеск: несколько ситуаций одновременно")
def storm(body: StormIn, _: dict = Depends(auth.current_user)):
    return eng().storm(body.count)


@app.delete("/api/incidents/{incident_id}", tags=["Нештатные ситуации"])
def resolve(incident_id: str, _: dict = Depends(auth.current_user)):
    try:
        return eng().resolve_incident(incident_id)
    except KeyError as ex:
        raise HTTPException(404, "Ситуация не найдена") from ex


# ---------- история и отчёты ----------
@app.get("/api/history/snapshots", tags=["История"], summary="Снимки для «перемотки»")
def snapshots(minutes: float = Query(15, ge=1, le=60), step: int = Query(2, ge=1, le=30),
              _: dict = Depends(auth.current_user)):
    return eng().storage.snapshots(minutes, step)


@app.get("/api/history/quality", tags=["История"])
def quality_history(minutes: float = Query(60, ge=1, le=4320), _: dict = Depends(auth.current_user)):
    return eng().storage.quality(minutes)


@app.get("/api/history/events", tags=["История"])
def events(minutes: float = Query(15, ge=1, le=4320), _: dict = Depends(auth.current_user)):
    return eng().storage.events(minutes)


@app.get("/api/report", tags=["История"], summary="Мини-отчёт (JSON, для печати в PDF)")
def report(minutes: float = Query(15, ge=1, le=180), _: dict = Depends(auth.current_user)):
    return eng().report(minutes)


@app.get("/api/report.csv", tags=["История"], summary="Мини-отчёт в CSV")
def report_csv(minutes: float = Query(15, ge=1, le=180), _: dict = Depends(auth.current_user)):
    rep = eng().report(minutes)
    buf = io.StringIO()
    w = csv.writer(buf, delimiter=";")
    w.writerow(["Отчёт Автодиспетчера", rep["section"], "модельное время", rep["generated_sim"]])
    w.writerow(["ДЕМОНСТРАЦИОННЫЕ ДАННЫЕ. Не является системой обеспечения безопасности движения."])
    w.writerow([])
    q = rep["quality"]
    w.writerow(["Индекс качества", q.get("value"), q.get("letter"), q.get("category_name")])
    w.writerow(["Фактор", "Оценка", "Вес", "Потеря индекса", "Пояснение"])
    for f in q.get("factors", []):
        w.writerow([f["name"], f["score"], f["weight"], f["loss"], f["detail"]])
    w.writerow([])
    w.writerow(["Поезд", "Прогнозная задержка, мин"])
    for t in rep["trains"]:
        w.writerow([t["id"], t["delay_min"]])
    w.writerow([])
    w.writerow(["Время (реальное)", "Модельное", "Тип", "Уровень", "Событие"])
    for ev in rep["events"]:
        w.writerow([time.strftime("%H:%M:%S", time.localtime(ev["ts"])), hhmm(ev["sim_t"]), ev["kind"], ev["level"], ev["message"]])
    w.writerow([])
    w.writerow(["Время (реальное)", "Модельное", "Индекс", "Категория"])
    for qh in rep["quality_history"]:
        w.writerow([time.strftime("%H:%M:%S", time.localtime(qh["ts"])), hhmm(qh["sim_t"]), qh["value"], qh["category"]])
    data = "\ufeff" + buf.getvalue()
    return Response(data, media_type="text/csv; charset=utf-8",
                    headers={"Content-Disposition": 'attachment; filename="autodispatcher_report.csv"'})


# ---------- конфигурация ----------
@app.get("/api/config", tags=["Настройки"])
def get_config(_: dict = Depends(auth.current_user)):
    return eng().cfg_store.editable_view()


@app.put("/api/config", tags=["Настройки"], summary="Изменить веса индекса, пороги, параметры (admin)")
def put_config(patch: dict, user: dict = Depends(auth.admin_user)):
    e = eng()
    try:
        view = e.cfg_store.update(patch)
    except (ValueError, TypeError, KeyError) as ex:
        raise HTTPException(400, f"Некорректная конфигурация: {ex}") from ex
    e._apply_config()
    e.storage.add_event(e.sim_now(), "config", "info", f"Настройки изменены пользователем {user['username']}")
    return view


# ---------- WebSocket ----------
@app.websocket("/ws")
async def ws_live(ws: WebSocket, token: str | None = None):
    user = auth.verify(token)
    if not user:
        await ws.close(code=4401)
        return
    e = eng()
    await ws.accept()
    hello = {"type": "hello", "user": user, "topology": e.topo.to_dict(), "accel": e.accel,
             "strategies": e.cfg["dispatcher"]["strategies"],
             "categories": {k: {"name": c.name, "priority": c.priority} for k, c in e.cats.items()}}
    await ws.send_text(json.dumps(hello, ensure_ascii=False))
    if e.result:
        await ws.send_text(json.dumps(e.result, ensure_ascii=False))
    if e._last_tick:
        await ws.send_text(json.dumps(e._last_tick, ensure_ascii=False))
    e.clients.add(ws)
    try:
        while True:
            msg = await ws.receive_text()
            if msg == "ping":
                await ws.send_text('{"type":"pong"}')
    except WebSocketDisconnect:
        pass
    finally:
        e.clients.discard(ws)


@app.websocket("/ws/ingest")
async def ws_ingest(ws: WebSocket, token: str | None = None):
    """Приём внешнего потока телеметрии (например, симулятора организатора). Формат — как у внутреннего симулятора."""
    if not auth.verify(token):
        await ws.close(code=4401)
        return
    e = eng()
    await ws.accept()
    try:
        while True:
            data = json.loads(await ws.receive_text())
            for m in data if isinstance(data, list) else [data]:
                e.bus.publish("telemetry.raw", m)
    except (WebSocketDisconnect, json.JSONDecodeError):
        pass


# ---------- дашборд ----------
STATIC = settings.BASE_DIR / "app" / "static"
app.mount("/static", StaticFiles(directory=STATIC), name="static")


@app.get("/", include_in_schema=False)
def index():
    return FileResponse(STATIC / "index.html")
