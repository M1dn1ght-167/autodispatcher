"""Настройки окружения. Секреты задаются только через переменные окружения."""
import logging
import os
import secrets
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
CONFIG_PATH = Path(os.getenv("CONFIG_PATH", BASE_DIR / "config" / "config.yaml"))
TOPOLOGY_PATH = Path(os.getenv("TOPOLOGY_PATH", BASE_DIR / "data" / "topology.json"))
DB_PATH = Path(os.getenv("DB_PATH", BASE_DIR / "var" / "autodispatcher.db"))
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
TOKEN_TTL_S = int(os.getenv("TOKEN_TTL_S", "43200"))

_log = logging.getLogger("settings")

SECRET_KEY = os.getenv("SECRET_KEY") or secrets.token_hex(32)
if not os.getenv("SECRET_KEY"):
    _log.warning("SECRET_KEY не задан — сгенерирован временный ключ (токены сбросятся при перезапуске)")

USERS = {
    os.getenv("DISPATCHER_USER", "dispatcher"): (os.getenv("DISPATCHER_PASSWORD", "dispatcher"), "dispatcher"),
    os.getenv("ADMIN_USER", "admin"): (os.getenv("ADMIN_PASSWORD", "admin"), "admin"),
}
if not os.getenv("ADMIN_PASSWORD"):
    _log.warning("ADMIN_PASSWORD не задан — используется демо-пароль. Задайте его в .env")
