"""Тестовый сценарий демо: опоздание → закрытие перегона → всплеск ×10 → снятие.

Запуск (сервер должен работать):  python scripts/demo_scenario.py http://localhost:8000
Печатает время пересчёта плана и изменение индекса качества на каждом шаге.
"""
import json
import sys
import time
import urllib.request

BASE = sys.argv[1] if len(sys.argv) > 1 else "http://localhost:8000"


def call(method, path, body=None, token=None):
    req = urllib.request.Request(BASE + path, method=method, data=json.dumps(body).encode() if body is not None else None,
                                 headers={"Content-Type": "application/json", **({"Authorization": "Bearer " + token} if token else {})})
    with urllib.request.urlopen(req) as r:
        return json.loads(r.read() or b"null")


def wait_plan(token, prev):
    t0 = time.time()
    while time.time() - t0 < 10:
        p = call("GET", "/api/plan", token=token)
        if p["sim_t"] != prev:
            return p, (time.time() - t0) * 1000
        time.sleep(0.05)
    return p, None


def step(title, token, action):
    before = call("GET", "/api/plan", token=token)
    action()
    after, ms = wait_plan(token, before["sim_t"])
    print(f"{title:<38} индекс {before['quality']['value']:5.1f} → {after['quality']['value']:5.1f}  "
          f"«{after['strategy_label']}», расчёт {after['compute_ms']:.0f} мс, новый план через {ms:.0f} мс, "
          f"нерешённых конфликтов: {len(after['unresolved'])}")
    return after


tok = call("POST", "/api/auth/login", {"username": "dispatcher", "password": "dispatcher"})["token"]
state = call("GET", "/api/state", token=tok)
train = next(t["id"] for t in state["trains"] if t["status"] == "running")
step(f"1. Опоздание {train} на 15 мин", tok, lambda: call("POST", "/api/incidents", {"type": "delay", "train_id": train, "minutes": 15}, tok))
inc = {}
step("2. Закрытие перегона KOK-AKB на 30 мин", tok,
     lambda: inc.update(call("POST", "/api/incidents", {"type": "closure", "segment_id": "KOK-AKB", "minutes": 30}, tok)))
step("3. Всплеск: 10 ситуаций одновременно", tok, lambda: call("POST", "/api/incidents/storm", {"count": 10}, tok))
step("4. Снятие закрытия перегона", tok, lambda: call("DELETE", f"/api/incidents/{inc['id']}", token=tok))
print("Готово. Варианты плана:", ", ".join(f"{v['label']} {v['index']}" for v in call("GET", "/api/plan", token=tok)["variants"]))
